// CollabPromo.com - State Store & Persistence Layer

import { INITIAL_CREATORS, INITIAL_ENQUIRIES, INITIAL_BRANDS } from './data.js';

const STORAGE_KEYS = {
  CREATORS: 'collabpromo_creators_v1',
  ENQUIRIES: 'collabpromo_enquiries_v1',
  BRANDS: 'collabpromo_brands_v1',
  AUTH: 'collabpromo_auth_v1'
};

class CollabPromoStore {
  constructor() {
    this.listeners = [];
    this.initData();
  }

  initData() {
    // 1. Creators
    const storedCreators = localStorage.getItem(STORAGE_KEYS.CREATORS);
    if (storedCreators) {
      try {
        this.creators = JSON.parse(storedCreators);
      } catch (e) {
        console.error('Failed to parse creators from storage', e);
        this.creators = [...INITIAL_CREATORS];
      }
    } else {
      this.creators = [...INITIAL_CREATORS];
      this.saveCreators();
    }

    // 2. Enquiries
    const storedEnquiries = localStorage.getItem(STORAGE_KEYS.ENQUIRIES);
    if (storedEnquiries) {
      try {
        this.enquiries = JSON.parse(storedEnquiries);
      } catch (e) {
        console.error('Failed to parse enquiries from storage', e);
        this.enquiries = [...INITIAL_ENQUIRIES];
      }
    } else {
      this.enquiries = [...INITIAL_ENQUIRIES];
      this.saveEnquiries();
    }

    // 3. Brands
    const storedBrands = localStorage.getItem(STORAGE_KEYS.BRANDS);
    if (storedBrands) {
      try {
        this.brands = JSON.parse(storedBrands);
      } catch (e) {
        this.brands = [...INITIAL_BRANDS];
      }
    } else {
      this.brands = [...INITIAL_BRANDS];
      this.saveBrands();
    }

    // 4. Auth State: default to guest or stored user
    const storedAuth = localStorage.getItem(STORAGE_KEYS.AUTH);
    if (storedAuth) {
      try {
        this.currentUser = JSON.parse(storedAuth);
      } catch (e) {
        this.currentUser = { role: 'guest' };
      }
    } else {
      this.currentUser = { role: 'guest' };
    }
  }

  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  notify() {
    for (const listener of this.listeners) {
      try {
        listener(this);
      } catch (e) {
        console.error('Error in store listener', e);
      }
    }
  }

  saveCreators() {
    localStorage.setItem(STORAGE_KEYS.CREATORS, JSON.stringify(this.creators));
  }

  saveEnquiries() {
    localStorage.setItem(STORAGE_KEYS.ENQUIRIES, JSON.stringify(this.enquiries));
  }

  saveBrands() {
    localStorage.setItem(STORAGE_KEYS.BRANDS, JSON.stringify(this.brands));
  }

  saveAuth() {
    localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(this.currentUser));
  }

  resetToDemoData() {
    this.creators = JSON.parse(JSON.stringify(INITIAL_CREATORS));
    this.enquiries = JSON.parse(JSON.stringify(INITIAL_ENQUIRIES));
    this.brands = JSON.parse(JSON.stringify(INITIAL_BRANDS));
    this.currentUser = { role: 'guest' };
    this.saveCreators();
    this.saveEnquiries();
    this.saveBrands();
    this.saveAuth();
    this.notify();
  }

  // Auth Operations
  login(role, payload = {}) {
    if (role === 'creator') {
      const creator = this.creators.find(c => c.id === payload.id) || payload;
      this.currentUser = {
        role: 'creator',
        id: creator.id,
        name: creator.name,
        handle: creator.handle,
        email: creator.privateEmail || payload.email,
        profile: creator
      };
    } else if (role === 'brand') {
      this.currentUser = {
        role: 'brand',
        id: payload.id || 'br-1',
        name: payload.name || 'Lumina Skin Co.',
        contactPerson: payload.contactPerson || 'Sarah Jenkins',
        email: payload.email || 's.jenkins@luminaskin.example',
        category: payload.category || 'Beauty & Skincare'
      };
    } else if (role === 'admin') {
      this.currentUser = {
        role: 'admin',
        name: 'Platform Coordinator',
        email: 'admin@collabpromo.com'
      };
    } else {
      this.currentUser = { role: 'guest' };
    }
    this.saveAuth();
    this.notify();
  }

  logout() {
    this.currentUser = { role: 'guest' };
    this.saveAuth();
    this.notify();
  }

  getCurrentUser() {
    return this.currentUser;
  }

  // Creator Access & Public Privacy Shielding
  getPublicCreators() {
    // Only return creators who have consented to directory listing AND are approved
    return this.creators
      .filter(c => c.hasConsented === true && c.status === 'approved')
      .map(c => {
        // Strict Privacy Rule: Never expose privateEmail or privatePhone to brands/visitors
        const { privateEmail, privatePhone, submittedAt, ...publicData } = c;
        return publicData;
      });
  }

  getAllCreators() {
    // Platform Administrator view: includes pending and unconsented for moderation
    return [...this.creators];
  }

  getCreatorById(id, includePrivate = false) {
    const creator = this.creators.find(c => c.id === id);
    if (!creator) return null;
    if (!includePrivate) {
      const { privateEmail, privatePhone, ...publicData } = creator;
      return publicData;
    }
    return { ...creator };
  }

  addCreator(creatorInput) {
    const newId = 'cr-' + (Date.now().toString(36) + Math.random().toString(36).substr(2, 4));
    const newCreator = {
      id: newId,
      name: creatorInput.name.trim(),
      handle: creatorInput.handle.trim().startsWith('@') ? creatorInput.handle.trim() : '@' + creatorInput.handle.trim(),
      avatar: creatorInput.avatar || `https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80`,
      platform: creatorInput.platform || 'Instagram',
      profileUrl: creatorInput.profileUrl.trim(),
      niche: creatorInput.niche,
      location: creatorInput.location.trim(),
      followers: parseInt(creatorInput.followers, 10) || 0,
      avgViews: creatorInput.avgViews ? parseInt(creatorInput.avgViews, 10) : 0,
      currency: creatorInput.currency || 'USD',
      currencySymbol: creatorInput.currency === 'EUR' ? '€' : creatorInput.currency === 'GBP' ? '£' : creatorInput.currency === 'INR' ? '₹' : '$',
      rateReel: parseFloat(creatorInput.rateReel) || 0,
      ratePost: parseFloat(creatorInput.ratePost) || 0,
      rateStory: creatorInput.rateStory ? parseFloat(creatorInput.rateStory) : 0,
      bundleRate: creatorInput.bundleRate ? parseFloat(creatorInput.bundleRate) : 0,
      deliverablesNote: creatorInput.deliverablesNote ? creatorInput.deliverablesNote.trim() : 'Standard deliverables with 1 revision round.',
      isOpenToCollabs: Boolean(creatorInput.isOpenToCollabs),
      hasConsented: Boolean(creatorInput.hasConsented),
      status: 'approved', // Auto-approved for this prototype so creator can immediately see themselves in directory
      isSample: false,
      bio: creatorInput.bio ? creatorInput.bio.trim() : 'Authentic creator open to qualified brand partnerships.',
      privateEmail: creatorInput.privateEmail.trim(),
      privatePhone: creatorInput.privatePhone ? creatorInput.privatePhone.trim() : '',
      preferredContact: creatorInput.preferredContact || 'Email',
      submittedAt: new Date().toISOString()
    };

    this.creators.unshift(newCreator);
    this.saveCreators();
    this.notify();
    return newCreator;
  }

  updateCreator(id, updates) {
    const index = this.creators.findIndex(c => c.id === id);
    if (index === -1) return false;

    this.creators[index] = {
      ...this.creators[index],
      ...updates,
      id // preserve original id
    };

    // If current user is this creator, update session profile as well
    if (this.currentUser.role === 'creator' && this.currentUser.id === id) {
      this.currentUser.profile = this.creators[index];
      this.currentUser.name = this.creators[index].name;
      this.currentUser.handle = this.creators[index].handle;
      this.saveAuth();
    }

    this.saveCreators();
    this.notify();
    return this.creators[index];
  }

  setCreatorStatus(id, newStatus) {
    const creator = this.creators.find(c => c.id === id);
    if (creator) {
      creator.status = newStatus;
      this.saveCreators();
      this.notify();
      return true;
    }
    return false;
  }

  deleteCreator(id) {
    this.creators = this.creators.filter(c => c.id !== id);
    this.saveCreators();
    this.notify();
    return true;
  }

  // Enquiry Access & Management
  getAllEnquiries() {
    return [...this.enquiries];
  }

  getEnquiriesForBrand(brandEmail) {
    if (!brandEmail) return [];
    return this.enquiries.filter(e => e.workEmail?.toLowerCase() === brandEmail.toLowerCase());
  }

  getEnquiriesForCreator(creatorId) {
    if (!creatorId) return [];
    return this.enquiries.filter(e => e.selectedCreatorIds && e.selectedCreatorIds.includes(creatorId));
  }

  addEnquiry(enquiryInput) {
    const refNumber = 'CP-' + Math.floor(1000 + Math.random() * 9000);
    const newEnquiry = {
      id: refNumber,
      brandName: enquiryInput.brandName.trim(),
      contactPerson: enquiryInput.contactPerson.trim(),
      workEmail: enquiryInput.workEmail.trim(),
      website: enquiryInput.website ? enquiryInput.website.trim() : '',
      businessCategory: enquiryInput.businessCategory || 'General',
      location: enquiryInput.location ? enquiryInput.location.trim() : '',
      campaignName: enquiryInput.campaignName.trim(),
      campaignGoal: enquiryInput.campaignGoal || 'Brand Awareness',
      productCategory: enquiryInput.productCategory || enquiryInput.businessCategory || 'General',
      targetNiche: enquiryInput.targetNiche || 'All',
      targetLocation: enquiryInput.targetLocation || 'Global',
      targetPlatform: enquiryInput.targetPlatform || 'All Platforms',
      desiredContentType: enquiryInput.desiredContentType || 'Reel / Video',
      budgetRange: enquiryInput.budgetRange || 'Flexible',
      timeline: enquiryInput.timeline || 'Flexible',
      selectedCreatorIds: Array.isArray(enquiryInput.selectedCreatorIds) ? enquiryInput.selectedCreatorIds : (enquiryInput.selectedCreatorId ? [enquiryInput.selectedCreatorId] : []),
      selectedCreatorNames: Array.isArray(enquiryInput.selectedCreatorNames) ? enquiryInput.selectedCreatorNames : (enquiryInput.selectedCreatorName ? [enquiryInput.selectedCreatorName] : []),
      campaignNotes: enquiryInput.campaignNotes ? enquiryInput.campaignNotes.trim() : '',
      usageRights: enquiryInput.usageRights || 'Organic Posting Only',
      status: 'submitted', // 'submitted' | 'under_review' | 'intro_made' | 'closed'
      coordinatorNotes: 'New brand enquiry submitted through CollabPromo. Pending review by platform mediator.',
      submittedAt: new Date().toISOString()
    };

    this.enquiries.unshift(newEnquiry);
    this.saveEnquiries();
    this.notify();
    return newEnquiry;
  }

  updateEnquiryStatus(id, newStatus, coordinatorNotes = null) {
    const enquiry = this.enquiries.find(e => e.id === id);
    if (enquiry) {
      enquiry.status = newStatus;
      if (coordinatorNotes !== null) {
        enquiry.coordinatorNotes = coordinatorNotes;
      }
      this.saveEnquiries();
      this.notify();
      return true;
    }
    return false;
  }

  // Brand Management
  addBrand(brandInput) {
    const newId = 'br-' + (Date.now().toString(36) + Math.random().toString(36).substr(2, 4));
    const newBrand = {
      id: newId,
      name: brandInput.name.trim(),
      contactPerson: brandInput.contactPerson.trim(),
      email: brandInput.email.trim(),
      website: brandInput.website ? brandInput.website.trim() : '',
      category: brandInput.category || 'E-commerce',
      location: brandInput.location ? brandInput.location.trim() : ''
    };
    this.brands.push(newBrand);
    this.saveBrands();
    this.notify();
    return newBrand;
  }
}

export const store = new CollabPromoStore();
