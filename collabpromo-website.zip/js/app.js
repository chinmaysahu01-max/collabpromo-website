// CollabPromo.com - Main Application Logic & View Controller

import { store } from './store.js';
import { PLATFORMS, NICHES } from './data.js';

class CollabPromoApp {
  constructor() {
    this.currentView = 'home';
    this.filters = {
      search: '',
      platform: 'all',
      niche: 'All Categories',
      location: '',
      minFollowers: null,
      maxFollowers: null,
      minRateReel: null,
      maxRateReel: null,
      minRatePost: null,
      maxRatePost: null,
      openToCollabsOnly: false,
      sortBy: 'followers_desc'
    };
    this.activeModal = null;
    this.selectedCreatorForModal = null;

    this.init();
  }

  init() {
    // Subscribe to store updates
    this.unsubscribeStore = store.subscribe(() => {
      this.updateAuthUI();
      this.renderCurrentView();
    });

    // Handle hash routing
    window.addEventListener('hashchange', () => this.handleHashChange());
    this.handleHashChange();

    // Setup global listeners (modals, role switcher, mobile nav)
    this.setupGlobalEvents();
    this.updateAuthUI();
  }

  handleHashChange() {
    const hash = window.location.hash.replace('#', '') || 'home';
    const validViews = [
      'home',
      'directory',
      'creator-register',
      'creator-dashboard',
      'brand-register',
      'brand-dashboard',
      'admin-portal',
      'about',
      'privacy',
      'terms'
    ];

    if (validViews.includes(hash)) {
      this.navigateTo(hash, false);
    } else {
      this.navigateTo('home', false);
    }
  }

  navigateTo(viewName, updateHash = true) {
    this.currentView = viewName;
    if (updateHash) {
      window.location.hash = viewName;
    }

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Update active nav styling
    document.querySelectorAll('.nav-link').forEach(link => {
      const targetView = link.getAttribute('data-view');
      if (targetView === viewName) {
        link.classList.add('text-blue-600', 'font-semibold');
        link.classList.remove('text-slate-600');
      } else {
        link.classList.remove('text-blue-600', 'font-semibold');
        link.classList.add('text-slate-600');
      }
    });

    this.renderCurrentView();
  }

  updateAuthUI() {
    const currentUser = store.getCurrentUser();
    const roleIndicator = document.getElementById('role-indicator-badge');
    const userRoleText = document.getElementById('user-role-text');
    const userAccountMenu = document.getElementById('user-account-menu');
    const guestAccountMenu = document.getElementById('guest-account-menu');
    const navCreatorDashboard = document.getElementById('nav-creator-dashboard');
    const navBrandDashboard = document.getElementById('nav-brand-dashboard');
    const navAdminPortal = document.getElementById('nav-admin-portal');

    if (!roleIndicator) return;

    if (currentUser.role === 'creator') {
      roleIndicator.className = 'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-purple-50 text-purple-700 border border-purple-200';
      roleIndicator.innerHTML = `<span class="w-2 h-2 rounded-full bg-purple-500 animate-pulse"></span> Creator: ${this.escapeHtml(currentUser.name || currentUser.handle || 'Creator')}`;
      if (userAccountMenu) userAccountMenu.classList.remove('hidden');
      if (guestAccountMenu) guestAccountMenu.classList.add('hidden');
      if (navCreatorDashboard) navCreatorDashboard.classList.remove('hidden');
      if (navBrandDashboard) navBrandDashboard.classList.add('hidden');
      if (navAdminPortal) navAdminPortal.classList.add('hidden');
    } else if (currentUser.role === 'brand') {
      roleIndicator.className = 'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200';
      roleIndicator.innerHTML = `<span class="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span> Brand: ${this.escapeHtml(currentUser.name || 'Brand')}`;
      if (userAccountMenu) userAccountMenu.classList.remove('hidden');
      if (guestAccountMenu) guestAccountMenu.classList.add('hidden');
      if (navCreatorDashboard) navCreatorDashboard.classList.add('hidden');
      if (navBrandDashboard) navBrandDashboard.classList.remove('hidden');
      if (navAdminPortal) navAdminPortal.classList.add('hidden');
    } else if (currentUser.role === 'admin') {
      roleIndicator.className = 'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-50 text-amber-800 border border-amber-300';
      roleIndicator.innerHTML = `<span class="w-2 h-2 rounded-full bg-amber-500"></span> Platform Admin`;
      if (userAccountMenu) userAccountMenu.classList.remove('hidden');
      if (guestAccountMenu) guestAccountMenu.classList.add('hidden');
      if (navCreatorDashboard) navCreatorDashboard.classList.add('hidden');
      if (navBrandDashboard) navBrandDashboard.classList.add('hidden');
      if (navAdminPortal) navAdminPortal.classList.remove('hidden');
    } else {
      // Guest
      roleIndicator.className = 'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-600 border border-slate-200';
      roleIndicator.innerHTML = `<span class="w-2 h-2 rounded-full bg-slate-400"></span> Visitor (Demo Role Switcher)`;
      if (userAccountMenu) userAccountMenu.classList.add('hidden');
      if (guestAccountMenu) guestAccountMenu.classList.remove('hidden');
      if (navCreatorDashboard) navCreatorDashboard.classList.add('hidden');
      if (navBrandDashboard) navBrandDashboard.classList.add('hidden');
      if (navAdminPortal) navAdminPortal.classList.add('hidden');
    }
  }

  renderCurrentView() {
    const container = document.getElementById('app-main-content');
    if (!container) return;

    switch (this.currentView) {
      case 'home':
        container.innerHTML = this.renderHomeView();
        this.bindHomeEvents();
        break;
      case 'directory':
        container.innerHTML = this.renderDirectoryView();
        this.bindDirectoryEvents();
        break;
      case 'creator-register':
        container.innerHTML = this.renderCreatorRegisterView();
        this.bindCreatorRegisterEvents();
        break;
      case 'creator-dashboard':
        container.innerHTML = this.renderCreatorDashboardView();
        this.bindCreatorDashboardEvents();
        break;
      case 'brand-register':
        container.innerHTML = this.renderBrandRegisterView();
        this.bindBrandRegisterEvents();
        break;
      case 'brand-dashboard':
        container.innerHTML = this.renderBrandDashboardView();
        this.bindBrandDashboardEvents();
        break;
      case 'admin-portal':
        container.innerHTML = this.renderAdminPortalView();
        this.bindAdminPortalEvents();
        break;
      case 'about':
        container.innerHTML = this.renderAboutView();
        break;
      case 'privacy':
        container.innerHTML = this.renderPrivacyView();
        break;
      case 'terms':
        container.innerHTML = this.renderTermsView();
        break;
      default:
        container.innerHTML = this.renderHomeView();
        this.bindHomeEvents();
        break;
    }
  }

  // ==========================================
  // VIEW RENDERERS
  // ==========================================

  renderHomeView() {
    const featuredCreators = store.getPublicCreators().slice(0, 4);

    return `
      <!-- Top Trust Banner -->
      <section class="bg-gradient-to-r from-blue-50 via-indigo-50 to-emerald-50 border-b border-blue-100 py-2.5 px-4 text-xs sm:text-sm text-slate-700 text-center">
        <div class="max-w-6xl mx-auto flex flex-wrap items-center justify-center gap-2">
          <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-600 text-white">Platform Mediator</span>
          <span>Transparent rates. Zero spam. <strong>CollabPromo coordinates your introductions safely.</strong></span>
          <span class="hidden md:inline text-slate-400">|</span>
          <a href="#directory" class="text-blue-700 font-semibold hover:underline inline-flex items-center gap-1">Browse Creators &rarr;</a>
        </div>
      </section>

      <!-- Hero Section -->
      <section class="relative pt-12 pb-16 md:pt-20 md:pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div class="text-center max-w-3xl mx-auto">
          <!-- Role selector banner near top -->
          <div class="inline-flex p-1 rounded-xl bg-slate-100 border border-slate-200 mb-8 shadow-sm">
            <button id="hero-btn-brand-role" class="px-5 py-2 text-sm font-semibold rounded-lg transition-all bg-white text-blue-700 shadow-sm border border-slate-200/80">
              Continue as a Brand
            </button>
            <button id="hero-btn-creator-role" class="px-5 py-2 text-sm font-medium rounded-lg text-slate-600 hover:text-slate-900 transition-all">
              Continue as a Creator
            </button>
          </div>

          <h1 class="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight md:leading-none">
            Connect Your Brand with the Right <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">Social Media Creators</span>
          </h1>
          <p class="mt-5 text-lg sm:text-xl text-slate-600 leading-relaxed">
            CollabPromo connects brands with verified creators for reels, videos, posts, and stories. We act as your trusted mediator: upfront rate cards, protected creator contacts, and structured campaign introductions.
          </p>

          <div class="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="#directory" class="w-full sm:w-auto px-8 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-lg shadow-blue-600/20 transition-all text-center flex items-center justify-center gap-2">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
              Explore Creator Directory
            </a>
            <a href="#creator-register" class="w-full sm:w-auto px-8 py-3.5 bg-white hover:bg-slate-50 text-slate-800 font-semibold rounded-xl border border-slate-300 shadow-sm transition-all text-center">
              Submit Your Creator Profile & Rates
            </a>
          </div>

          <div class="mt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-500">
            <span class="inline-flex items-center gap-1.5"><svg class="w-4 h-4 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg> Transparent Upfront Rates</span>
            <span class="inline-flex items-center gap-1.5"><svg class="w-4 h-4 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg> Private Emails Never Exposed</span>
            <span class="inline-flex items-center gap-1.5"><svg class="w-4 h-4 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg> Mediated Campaign Briefs</span>
          </div>
        </div>

        <!-- Role Quick-Cards -->
        <div class="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <!-- Brand Card -->
          <div class="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
            <div class="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-bl-full pointer-events-none"></div>
            <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-blue-100 text-blue-600 font-bold mb-4">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
            </div>
            <h2 class="text-xl font-bold text-slate-900">For Brands & Marketers</h2>
            <p class="mt-2 text-slate-600 text-sm leading-relaxed">
              Find creators aligned with your target niche, location, and budget. Compare rate cards for reels, posts, and stories without endless back-and-forth emails.
            </p>
            <div class="mt-6 flex flex-wrap gap-3">
              <a href="#directory" class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors">
                Browse Creator Directory
              </a>
              <a href="#brand-register" class="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-medium rounded-lg transition-colors">
                Register as a Brand
              </a>
            </div>
          </div>

          <!-- Creator Card -->
          <div class="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
            <div class="absolute top-0 right-0 w-32 h-32 bg-purple-50 rounded-bl-full pointer-events-none"></div>
            <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-purple-100 text-purple-600 font-bold mb-4">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
            </div>
            <h2 class="text-xl font-bold text-slate-900">For Social Media Creators</h2>
            <p class="mt-2 text-slate-600 text-sm leading-relaxed">
              Publish your verified rates and deliverables for reels and posts. Keep your personal contact shielded while receiving pre-qualified campaign briefs through CollabPromo.
            </p>
            <div class="mt-6 flex flex-wrap gap-3">
              <a href="#creator-register" class="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white text-sm font-semibold rounded-lg transition-colors">
                Submit Your Rates
              </a>
              <button id="btn-login-demo-creator" class="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-medium rounded-lg transition-colors">
                View Creator Portal Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      <!-- How it Works Section -->
      <section class="py-16 bg-slate-50 border-y border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="text-center max-w-2xl mx-auto">
            <span class="text-xs font-bold uppercase tracking-wider text-blue-600">Clear & Transparent Process</span>
            <h2 class="mt-2 text-3xl font-extrabold text-slate-900">How CollabPromo Works</h2>
            <p class="mt-3 text-slate-600 text-base">
              A reliable mediation platform designed to save time and eliminate guesswork for both creators and advertisers.
            </p>
          </div>

          <div class="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            <!-- Step 1 -->
            <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm relative">
              <div class="w-10 h-10 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-lg mb-4">
                1
              </div>
              <h3 class="text-lg font-bold text-slate-900">Creators Share Profiles & Rates</h3>
              <p class="mt-2 text-sm text-slate-600 leading-relaxed">
                Creators submit channel handles, verified follower tiers, niche categories, and clear rate cards for reels, feed posts, or content bundles. Private emails remain confidential.
              </p>
            </div>

            <!-- Step 2 -->
            <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm relative">
              <div class="w-10 h-10 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-lg mb-4">
                2
              </div>
              <h3 class="text-lg font-bold text-slate-900">Brands Filter & Discover</h3>
              <p class="mt-2 text-sm text-slate-600 leading-relaxed">
                Brands search across platforms (Instagram, YouTube, TikTok) and filter by content niche, follower volume, and budget tiers to find genuine creator fits.
              </p>
            </div>

            <!-- Step 3 -->
            <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm relative">
              <div class="w-10 h-10 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-lg mb-4">
                3
              </div>
              <h3 class="text-lg font-bold text-slate-900">Mediated Campaign Introductions</h3>
              <p class="mt-2 text-sm text-slate-600 leading-relaxed">
                Interested brands submit a structured campaign enquiry with clear scope and budget. CollabPromo reviews the brief and coordinates seamless introductions between both parties.
              </p>
            </div>
          </div>

          <!-- Trust callout -->
          <div class="mt-10 p-5 rounded-xl mediator-notice text-sm text-slate-700 flex items-start gap-4 max-w-4xl mx-auto">
            <svg class="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <div>
              <strong class="font-semibold text-slate-900">Important Platform Notice:</strong>
              CollabPromo acts as an introductory mediator. Submitting a creator profile does not guarantee paid brand sponsorships, and sending a brand enquiry is an exploratory proposal rather than an automatic booking until both parties confirm campaign deliverables.
            </div>
          </div>
        </div>
      </section>

      <!-- Featured Creators Section -->
      <section class="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-bold uppercase tracking-wider text-blue-600">Creator Spotlight</span>
              <span class="px-2 py-0.5 rounded text-[10px] font-medium badge-sample">Sample Listings</span>
            </div>
            <h2 class="mt-1 text-2xl sm:text-3xl font-extrabold text-slate-900">Featured Creator Profiles</h2>
            <p class="mt-1 text-slate-500 text-sm">Explore a snapshot of creators and transparent rates in our directory.</p>
          </div>
          <a href="#directory" class="text-sm font-semibold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1">
            View All ${store.getPublicCreators().length} Creators &rarr;
          </a>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          ${featuredCreators.map(creator => this.renderCreatorCardHtml(creator)).join('')}
        </div>
      </section>

      <!-- Benefits Section: Side-by-side -->
      <section class="py-16 bg-white border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="text-center max-w-2xl mx-auto mb-12">
            <h2 class="text-2xl sm:text-3xl font-extrabold text-slate-900">Why Brands & Creators Choose CollabPromo</h2>
            <p class="mt-2 text-slate-600 text-sm sm:text-base">Designed for direct clarity, professional security, and mediated ease.</p>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Brand Benefits -->
            <div class="p-6 sm:p-8 rounded-2xl bg-slate-50 border border-slate-200">
              <div class="flex items-center gap-3 mb-6">
                <span class="p-2.5 rounded-lg bg-blue-100 text-blue-600">
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                </span>
                <h3 class="text-xl font-bold text-slate-900">Benefits for Brands</h3>
              </div>
              <ul class="space-y-4 text-sm text-slate-700">
                <li class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                  <div><strong>Transparent Rate Cards:</strong> Know exact starting costs for reels, videos, and posts before drafting campaign proposals.</div>
                </li>
                <li class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                  <div><strong>Targeted Discovery:</strong> Filter creators by specific niche, platform, follower count, and location in seconds.</div>
                </li>
                <li class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                  <div><strong>Structured Enquiries:</strong> Submit full campaign parameters (dates, rights, content type) for coordinated platform mediation.</div>
                </li>
                <li class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                  <div><strong>Higher Response Rates:</strong> Creators know enquiries have been vetted and meet their stated rate minimums.</div>
                </li>
              </ul>
            </div>

            <!-- Creator Benefits -->
            <div class="p-6 sm:p-8 rounded-2xl bg-slate-50 border border-slate-200">
              <div class="flex items-center gap-3 mb-6">
                <span class="p-2.5 rounded-lg bg-purple-100 text-purple-600">
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                </span>
                <h3 class="text-xl font-bold text-slate-900">Benefits for Creators</h3>
              </div>
              <ul class="space-y-4 text-sm text-slate-700">
                <li class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                  <div><strong>Guaranteed Privacy Shield:</strong> Your personal email and phone number are never exposed to scrapers or cold spammers.</div>
                </li>
                <li class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                  <div><strong>You Set Your Own Rates:</strong> Full control over pricing for reels, community posts, story tags, and bundles.</div>
                </li>
                <li class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                  <div><strong>Pre-Filtered Collaboration Enquiries:</strong> CollabPromo filters out lowball offers before passing campaign briefs to you.</div>
                </li>
                <li class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                  <div><strong>Toggle Availability Anytime:</strong> Pause your directory listing whenever you are booked up with client work.</div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <!-- Bottom Call To Action Banner -->
      <section class="py-16 bg-slate-900 text-white">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 text-center">
          <h2 class="text-2xl sm:text-3xl font-extrabold tracking-tight">Ready to Start Your Next Promotion?</h2>
          <p class="mt-3 text-slate-300 max-w-2xl mx-auto text-base">
            Whether you are a brand looking to amplify your message or a creator looking to monetize your audience with reputable partners, CollabPromo makes it simple.
          </p>
          <div class="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="#directory" class="w-full sm:w-auto px-7 py-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl transition-colors">
              Find Creators for Campaign
            </a>
            <a href="#creator-register" class="w-full sm:w-auto px-7 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold rounded-xl transition-colors">
              Join as a Creator
            </a>
          </div>
        </div>
      </section>
    `;
  }

  renderDirectoryView() {
    const publicCreators = store.getPublicCreators();
    const filteredCreators = this.applyFilters(publicCreators);

    return `
      <div class="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <!-- Directory Header -->
        <div class="flex flex-col md:flex-row md:items-end justify-between pb-6 border-b border-slate-200 gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-bold uppercase tracking-wider text-blue-600">Brand Discovery</span>
              <span class="px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">Verified Rate Cards</span>
            </div>
            <h1 class="mt-1 text-2xl sm:text-3xl font-extrabold text-slate-900">Creator Discovery Directory</h1>
            <p class="mt-1 text-sm text-slate-500">
              Browse approved social media creators. Filter by platform, niche, follower tier, and reel or post rates.
            </p>
          </div>
          <div class="flex items-center gap-3">
            <button id="btn-quick-enquiry" class="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-lg shadow-sm flex items-center gap-2 transition-colors">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
              Start General Campaign Enquiry
            </button>
          </div>
        </div>

        <!-- Filter & Search Toolbar -->
        <div class="mt-6 bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-sm space-y-4">
          <!-- Row 1: Search & Quick Platform Pills -->
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
            <!-- Search Input -->
            <div class="lg:col-span-5 relative">
              <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
              </div>
              <input
                type="text"
                id="directory-search"
                value="${this.escapeHtml(this.filters.search)}"
                placeholder="Search by creator name, @handle, or keyword..."
                class="w-full pl-10 pr-4 py-2 text-sm rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-white"
              />
            </div>

            <!-- Platform Pills -->
            <div class="lg:col-span-7 flex flex-wrap items-center gap-2">
              <span class="text-xs font-semibold text-slate-500 mr-1">Platform:</span>
              ${PLATFORMS.map(p => `
                <button
                  type="button"
                  data-platform="${p.id}"
                  class="platform-filter-pill px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    this.filters.platform === p.id
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }"
                >
                  ${p.name}
                </button>
              `).join('')}
            </div>
          </div>

          <!-- Row 2: Secondary Dropdown Filters -->
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-slate-100">
            <!-- Niche Filter -->
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1" for="filter-niche">Niche / Category</label>
              <select id="filter-niche" class="w-full text-xs py-2 px-2.5 rounded-lg border border-slate-300 bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
                ${NICHES.map(n => `<option value="${n}" ${this.filters.niche === n ? 'selected' : ''}>${n}</option>`).join('')}
              </select>
            </div>

            <!-- Follower Range Filter -->
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1" for="filter-followers">Follower Tier</label>
              <select id="filter-followers" class="w-full text-xs py-2 px-2.5 rounded-lg border border-slate-300 bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
                <option value="all">Any Follower Count</option>
                <option value="micro" ${this.filters.maxFollowers === 50000 ? 'selected' : ''}>Micro (< 50K followers)</option>
                <option value="mid" ${this.filters.minFollowers === 50000 && this.filters.maxFollowers === 200000 ? 'selected' : ''}>Mid-tier (50K – 200K)</option>
                <option value="macro" ${this.filters.minFollowers === 200000 ? 'selected' : ''}>Macro (200K+ followers)</option>
              </select>
            </div>

            <!-- Max Reel Rate Filter -->
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1" for="filter-reel-rate">Reel/Video Rate</label>
              <select id="filter-reel-rate" class="w-full text-xs py-2 px-2.5 rounded-lg border border-slate-300 bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
                <option value="all">Any Rate</option>
                <option value="500" ${this.filters.maxRateReel === 500 ? 'selected' : ''}>Under $500 / Reel</option>
                <option value="1000" ${this.filters.maxRateReel === 1000 ? 'selected' : ''}>Under $1,000 / Reel</option>
                <option value="1500" ${this.filters.maxRateReel === 1500 ? 'selected' : ''}>Under $1,500 / Reel</option>
              </select>
            </div>

            <!-- Sort Option -->
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1" for="filter-sort">Sort Creators By</label>
              <select id="filter-sort" class="w-full text-xs py-2 px-2.5 rounded-lg border border-slate-300 bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
                <option value="followers_desc" ${this.filters.sortBy === 'followers_desc' ? 'selected' : ''}>Followers: High to Low</option>
                <option value="followers_asc" ${this.filters.sortBy === 'followers_asc' ? 'selected' : ''}>Followers: Low to High</option>
                <option value="reel_asc" ${this.filters.sortBy === 'reel_asc' ? 'selected' : ''}>Reel Rate: Low to High</option>
                <option value="reel_desc" ${this.filters.sortBy === 'reel_desc' ? 'selected' : ''}>Reel Rate: High to Low</option>
                <option value="post_asc" ${this.filters.sortBy === 'post_asc' ? 'selected' : ''}>Post Rate: Low to High</option>
              </select>
            </div>
          </div>

          <!-- Row 3: Active Filters Summary & Checkbox -->
          <div class="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs text-slate-600">
            <div class="flex items-center gap-2">
              <label class="inline-flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  id="filter-open-collabs"
                  ${this.filters.openToCollabsOnly ? 'checked' : ''}
                  class="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <span class="font-medium text-slate-700">Open for collaborations only</span>
              </label>
            </div>

            <div class="flex items-center gap-4">
              <span class="text-slate-500 font-medium">Showing <strong class="text-slate-900">${filteredCreators.length}</strong> of ${publicCreators.length} approved creators</span>
              <button id="btn-reset-filters" class="text-blue-600 hover:text-blue-800 font-semibold underline text-xs">
                Reset Filters
              </button>
            </div>
          </div>
        </div>

        <!-- Directory Grid -->
        ${
          filteredCreators.length > 0
            ? `
              <div class="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                ${filteredCreators.map(creator => this.renderCreatorCardHtml(creator)).join('')}
              </div>
            `
            : `
              <!-- Empty State -->
              <div class="mt-12 bg-white rounded-xl border border-slate-200 p-12 text-center max-w-lg mx-auto">
                <div class="w-16 h-16 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center mb-4">
                  <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <h3 class="text-lg font-bold text-slate-900">No creators match your current filters</h3>
                <p class="mt-2 text-sm text-slate-500">
                  Try broadening your search term, clearing follower/rate brackets, or selecting "All Platforms".
                </p>
                <button id="btn-empty-reset" class="mt-5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors">
                  Reset All Filters
                </button>
              </div>
            `
        }
      </div>
    `;
  }

  renderCreatorCardHtml(creator) {
    const platformBadgeClass =
      creator.platform === 'Instagram'
        ? 'badge-instagram'
        : creator.platform === 'YouTube'
        ? 'badge-youtube'
        : 'badge-tiktok';

    return `
      <div class="creator-card bg-white rounded-xl border border-slate-200 p-5 flex flex-col justify-between shadow-xs">
        <div>
          <!-- Header: Avatar + Handles + Platform -->
          <div class="flex items-start gap-3">
            <img
              src="${this.escapeHtml(creator.avatar)}"
              alt="${this.escapeHtml(creator.name)}"
              class="w-13 h-13 rounded-full object-cover border border-slate-200 flex-shrink-0"
              loading="lazy"
              onerror="this.src='https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'"
            />
            <div class="min-w-0 flex-1">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs px-2 py-0.5 rounded font-semibold ${platformBadgeClass}">
                  ${this.escapeHtml(creator.platform)}
                </span>
                ${
                  creator.isSample
                    ? `<span class="text-[10px] px-1.5 py-0.5 rounded badge-sample font-medium" title="Sample profile for demo preview">Demo</span>`
                    : ''
                }
              </div>
              <h3 class="font-bold text-slate-900 text-base truncate mt-1">${this.escapeHtml(creator.name)}</h3>
              <p class="text-xs text-slate-500 truncate font-mono">${this.escapeHtml(creator.handle)}</p>
            </div>
          </div>

          <!-- Niche & Location badges -->
          <div class="mt-3 flex flex-wrap gap-1.5 text-xs">
            <span class="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md font-medium text-[11px]">
              ${this.escapeHtml(creator.niche)}
            </span>
            <span class="px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md text-[11px] flex items-center gap-1">
              <svg class="w-3 h-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path></svg>
              ${this.escapeHtml(creator.location)}
            </span>
          </div>

          <!-- Stats: Followers & Avg Views -->
          <div class="mt-4 grid grid-cols-2 gap-2 bg-slate-50 rounded-lg p-2.5 border border-slate-100 text-center">
            <div>
              <span class="block text-[11px] text-slate-500 uppercase font-medium">Followers</span>
              <span class="font-bold text-slate-900 text-sm">${this.formatNumber(creator.followers)}</span>
            </div>
            <div>
              <span class="block text-[11px] text-slate-500 uppercase font-medium">Avg Views</span>
              <span class="font-bold text-slate-900 text-sm">${creator.avgViews ? this.formatNumber(creator.avgViews) : '—'}</span>
            </div>
          </div>

          <!-- Rate Card Preview -->
          <div class="mt-3 space-y-1.5 text-xs">
            <div class="flex items-center justify-between text-slate-600">
              <span>Reel / Video:</span>
              <strong class="text-slate-900 font-bold">${creator.currencySymbol || '$'}${creator.rateReel}</strong>
            </div>
            <div class="flex items-center justify-between text-slate-600">
              <span>Static / Feed Post:</span>
              <strong class="text-slate-900 font-bold">${creator.currencySymbol || '$'}${creator.ratePost}</strong>
            </div>
            ${
              creator.bundleRate > 0
                ? `
                  <div class="flex items-center justify-between text-slate-600">
                    <span>Bundle Rate:</span>
                    <strong class="text-blue-700 font-bold">${creator.currencySymbol || '$'}${creator.bundleRate}</strong>
                  </div>
                `
                : ''
            }
          </div>

          <!-- Collab status pill -->
          <div class="mt-3">
            ${
              creator.isOpenToCollabs
                ? `<span class="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Open for Collaborations</span>`
                : `<span class="inline-flex items-center gap-1 text-[11px] font-medium text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full"><span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span> Currently Booked</span>`
            }
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="mt-5 pt-3 border-t border-slate-100 flex items-center gap-2">
          <button
            type="button"
            data-action="view-profile"
            data-creator-id="${creator.id}"
            class="flex-1 py-2 px-3 text-xs font-semibold rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors"
          >
            View Profile
          </button>
          <button
            type="button"
            data-action="enquire-creator"
            data-creator-id="${creator.id}"
            class="flex-1 py-2 px-3 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
          >
            Request Enquiry
          </button>
        </div>
      </div>
    `;
  }

  renderCreatorRegisterView() {
    return `
      <div class="py-10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <!-- Breadcrumb & Header -->
        <div class="mb-6">
          <a href="#home" class="text-xs font-semibold text-blue-600 hover:underline inline-flex items-center gap-1">&larr; Back to Home</a>
          <h1 class="mt-2 text-2xl sm:text-3xl font-extrabold text-slate-900">Creator Onboarding & Rate Card Submission</h1>
          <p class="mt-1 text-slate-600 text-sm">
            Join the CollabPromo network. Submit your channel stats and rates so brands can request campaigns through platform mediation.
          </p>
        </div>

        <!-- Privacy Shield Notice -->
        <div class="mb-6 p-4 rounded-xl bg-blue-50 border border-blue-200 text-xs sm:text-sm text-slate-700 flex items-start gap-3">
          <svg class="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
          <div>
            <strong class="font-semibold text-blue-900">Privacy Protection Guaranteed:</strong>
            Your personal email address and phone number are strictly confidential and will never be displayed in public brand directories. All campaign enquiries are mediated by CollabPromo.
          </div>
        </div>

        <!-- Form Card -->
        <form id="creator-register-form" class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-8" novalidate>
          <!-- Section 1: Creator & Channel Details -->
          <div>
            <h2 class="text-lg font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
              <span class="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">1</span>
              Personal & Channel Information
            </h2>

            <div class="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <!-- Name -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-name">
                  Full Name / Legal Name <span class="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="cr-name"
                  name="name"
                  placeholder="e.g. Maya Lin"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-cr-name">Please enter your name.</div>
              </div>

              <!-- Private Email -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-email">
                  Private Email Address <span class="text-red-500">*</span>
                  <span class="text-slate-400 font-normal">(Never shown publicly)</span>
                </label>
                <input
                  type="email"
                  id="cr-email"
                  name="privateEmail"
                  placeholder="e.g. maya@example.com"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-cr-email">Please enter a valid email address.</div>
              </div>

              <!-- Preferred Contact Method -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-contact-method">
                  Preferred Contact Method
                </label>
                <select id="cr-contact-method" name="preferredContact" class="w-full text-sm p-2.5 rounded-lg border border-slate-300 bg-white">
                  <option value="Email">Email</option>
                  <option value="WhatsApp">WhatsApp</option>
                  <option value="Telegram">Telegram</option>
                  <option value="Phone">Phone</option>
                </select>
              </div>

              <!-- Phone (Optional) -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-phone">
                  Phone / WhatsApp Number <span class="text-slate-400 font-normal">(Optional, private)</span>
                </label>
                <input
                  type="tel"
                  id="cr-phone"
                  name="privatePhone"
                  placeholder="+1 (555) 000-0000"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <!-- Social Media Platform -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-platform">
                  Primary Social Platform <span class="text-red-500">*</span>
                </label>
                <select id="cr-platform" name="platform" class="w-full text-sm p-2.5 rounded-lg border border-slate-300 bg-white" required>
                  <option value="Instagram">Instagram</option>
                  <option value="YouTube">YouTube</option>
                  <option value="TikTok">TikTok</option>
                  <option value="X">X (Twitter)</option>
                </select>
              </div>

              <!-- Channel Handle -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-handle">
                  Channel Handle / Account Name <span class="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="cr-handle"
                  name="handle"
                  placeholder="e.g. @mayacreates"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-cr-handle">Please enter your channel handle.</div>
              </div>

              <!-- Direct Profile Link -->
              <div class="sm:col-span-2">
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-profile-url">
                  Direct Profile Link <span class="text-red-500">*</span>
                </label>
                <input
                  type="url"
                  id="cr-profile-url"
                  name="profileUrl"
                  placeholder="https://instagram.com/mayacreates"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-cr-url">Please enter a valid URL (starting with http:// or https://).</div>
              </div>

              <!-- Niche / Category -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-niche">
                  Content Category / Niche <span class="text-red-500">*</span>
                </label>
                <select id="cr-niche" name="niche" class="w-full text-sm p-2.5 rounded-lg border border-slate-300 bg-white" required>
                  ${NICHES.filter(n => n !== 'All Categories').map(n => `<option value="${n}">${n}</option>`).join('')}
                </select>
              </div>

              <!-- Location -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-location">
                  Location (City, Country) <span class="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="cr-location"
                  name="location"
                  placeholder="e.g. Los Angeles, USA"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-cr-location">Please enter your location.</div>
              </div>

              <!-- Followers Count -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-followers">
                  Follower / Subscriber Count <span class="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  id="cr-followers"
                  name="followers"
                  min="100"
                  placeholder="e.g. 50000"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-cr-followers">Please provide a valid follower count.</div>
              </div>

              <!-- Optional Avg Views -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-avg-views">
                  Average Video/Reel Views <span class="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="number"
                  id="cr-avg-views"
                  name="avgViews"
                  min="0"
                  placeholder="e.g. 15000"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <!-- Bio -->
              <div class="sm:col-span-2">
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-bio">
                  Short Bio & Content Style
                </label>
                <textarea
                  id="cr-bio"
                  name="bio"
                  rows="2"
                  placeholder="Briefly describe what your audience loves about your content and what kind of brands you partner with."
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                ></textarea>
              </div>
            </div>
          </div>

          <!-- Section 2: Rate Card & Commercials -->
          <div>
            <h2 class="text-lg font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
              <span class="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">2</span>
              Deliverable Rates & Scope
            </h2>

            <div class="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
              <!-- Currency -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-currency">Currency</label>
                <select id="cr-currency" name="currency" class="w-full text-sm p-2.5 rounded-lg border border-slate-300 bg-white">
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="CAD">CAD ($)</option>
                  <option value="INR">INR (₹)</option>
                </select>
              </div>

              <!-- Rate Reel -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-rate-reel">
                  Rate per Reel / Video <span class="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  id="cr-rate-reel"
                  name="rateReel"
                  min="0"
                  step="10"
                  placeholder="e.g. 500"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-cr-rate-reel">Please enter a valid rate.</div>
              </div>

              <!-- Rate Post -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-rate-post">
                  Rate per Static / Feed Post <span class="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  id="cr-rate-post"
                  name="ratePost"
                  min="0"
                  step="10"
                  placeholder="e.g. 300"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-cr-rate-post">Please enter a valid rate.</div>
              </div>

              <!-- Rate Story (Optional) -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-rate-story">
                  Rate per Story Tag <span class="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="number"
                  id="cr-rate-story"
                  name="rateStory"
                  min="0"
                  placeholder="e.g. 150"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <!-- Bundle Rate (Optional) -->
              <div class="sm:col-span-2">
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-rate-bundle">
                  Content Bundle Rate <span class="text-slate-400 font-normal">(Optional - e.g. 1 Reel + 2 Stories)</span>
                </label>
                <input
                  type="number"
                  id="cr-rate-bundle"
                  name="bundleRate"
                  min="0"
                  placeholder="e.g. 750"
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <!-- Deliverables Note -->
              <div class="sm:col-span-3">
                <label class="block text-xs font-bold text-slate-700 mb-1" for="cr-deliverables-note">
                  Notes on What Your Rates Include
                </label>
                <textarea
                  id="cr-deliverables-note"
                  name="deliverablesNote"
                  rows="2"
                  placeholder="e.g. Includes 2 rounds of edits, raw 4K footage export, 30-day organic posting rights. Paid advertising rights negotiable upon request."
                  class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                ></textarea>
              </div>
            </div>
          </div>

          <!-- Section 3: Availability & Legal Consent -->
          <div>
            <h2 class="text-lg font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
              <span class="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">3</span>
              Collaboration Availability & Consent
            </h2>

            <div class="mt-4 space-y-4">
              <!-- Open for Collabs Toggle -->
              <div class="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="cr-open-collabs"
                  name="isOpenToCollabs"
                  checked
                  class="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <label for="cr-open-collabs" class="text-sm font-semibold text-slate-800">
                  I am currently open to receiving brand collaboration enquiries.
                </label>
              </div>

              <!-- Explicit Directory Consent Checkbox -->
              <div class="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div class="flex items-start gap-3">
                  <input
                    type="checkbox"
                    id="cr-consent"
                    name="hasConsented"
                    class="w-4 h-4 mt-0.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                    required
                  />
                  <div>
                    <label for="cr-consent" class="text-xs sm:text-sm font-bold text-slate-900 cursor-pointer">
                      Consent for Directory Listing & Mediation <span class="text-red-500">*</span>
                    </label>
                    <p class="mt-1 text-xs text-slate-600 leading-relaxed">
                      I give permission to CollabPromo.com to display my channel name, platform link, content niche, follower count, and rate card in the creator directory for brands to browse. I understand my personal email and phone number will remain strictly private and handled via platform mediation.
                    </p>
                    <div class="field-error-text hidden" id="err-cr-consent">You must provide directory listing consent to submit your profile.</div>
                  </div>
                </div>
              </div>

              <!-- Disclaimer -->
              <p class="text-xs text-slate-500 italic">
                * Note: Submitting your creator profile does not guarantee campaign bookings. All brand proposals are reviewed by CollabPromo and subject to your final acceptance.
              </p>
            </div>
          </div>

          <!-- Submit Button -->
          <div class="pt-4 flex flex-col sm:flex-row items-center justify-end gap-3">
            <a href="#home" class="w-full sm:w-auto px-6 py-2.5 text-center text-sm font-semibold text-slate-600 hover:text-slate-900">
              Cancel
            </a>
            <button
              type="submit"
              class="w-full sm:w-auto px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-xl shadow-md transition-colors"
            >
              Submit Creator Profile & Rates
            </button>
          </div>
        </form>
      </div>
    `;
  }

  renderCreatorDashboardView() {
    const currentUser = store.getCurrentUser();
    // Use active profile or fallback to demo creator Maya Lin
    const creator = (currentUser.role === 'creator' && currentUser.profile)
      ? currentUser.profile
      : store.getCreatorById('cr-1', true);

    const enquiries = store.getEnquiriesForCreator(creator ? creator.id : 'cr-1');

    return `
      <div class="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
        <!-- Dashboard Top Header -->
        <div class="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-200 gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-bold uppercase tracking-wider text-purple-600">Creator Hub</span>
              <span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                Directory Status: ${creator && creator.status === 'approved' ? 'Active & Published' : 'Pending Review'}
              </span>
            </div>
            <h1 class="mt-1 text-2xl sm:text-3xl font-extrabold text-slate-900">
              Creator Dashboard: ${this.escapeHtml(creator ? creator.name : 'Creator')}
            </h1>
            <p class="mt-1 text-sm text-slate-500">
              Manage your rate card, update collaboration availability, and review brand enquiries coordinated by CollabPromo.
            </p>
          </div>

          <div class="flex items-center gap-3">
            <a href="#directory" class="px-4 py-2 text-xs font-semibold rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors">
              View Public Directory
            </a>
            <button id="btn-save-creator-dashboard" class="px-4 py-2 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors">
              Save Profile Updates
            </button>
          </div>
        </div>

        <!-- Privacy Status Card -->
        <div class="p-4 rounded-xl bg-purple-50 border border-purple-200 text-xs sm:text-sm text-slate-700 flex items-start gap-3">
          <svg class="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>
          <div>
            <strong class="font-semibold text-purple-900">Your Contact Security:</strong>
            Your email (<span class="font-mono text-purple-800">${this.escapeHtml(creator?.privateEmail || 'maya@sample.internal')}</span>) is protected behind CollabPromo mediation. Brands cannot view your raw email or phone.
          </div>
        </div>

        <!-- Main Layout: 2 Columns -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <!-- Left Column: Editable Rates & Details Form -->
          <div class="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
            <h2 class="text-base font-bold text-slate-900 pb-2 border-b border-slate-100">
              Manage Your Rate Card & Visibility
            </h2>

            <form id="creator-update-form" class="space-y-4">
              <input type="hidden" id="edit-creator-id" value="${creator ? creator.id : ''}">

              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Followers -->
                <div>
                  <label class="block text-xs font-bold text-slate-700 mb-1" for="dash-followers">Follower Count</label>
                  <input
                    type="number"
                    id="dash-followers"
                    value="${creator ? creator.followers : 10000}"
                    class="w-full text-sm p-2 rounded-lg border border-slate-300"
                  />
                </div>

                <!-- Avg Views -->
                <div>
                  <label class="block text-xs font-bold text-slate-700 mb-1" for="dash-views">Average Views</label>
                  <input
                    type="number"
                    id="dash-views"
                    value="${creator ? creator.avgViews : 0}"
                    class="w-full text-sm p-2 rounded-lg border border-slate-300"
                  />
                </div>

                <!-- Reel Rate -->
                <div>
                  <label class="block text-xs font-bold text-slate-700 mb-1" for="dash-rate-reel">Rate per Reel / Video ($)</label>
                  <input
                    type="number"
                    id="dash-rate-reel"
                    value="${creator ? creator.rateReel : 500}"
                    class="w-full text-sm p-2 rounded-lg border border-slate-300"
                  />
                </div>

                <!-- Post Rate -->
                <div>
                  <label class="block text-xs font-bold text-slate-700 mb-1" for="dash-rate-post">Rate per Post ($)</label>
                  <input
                    type="number"
                    id="dash-rate-post"
                    value="${creator ? creator.ratePost : 300}"
                    class="w-full text-sm p-2 rounded-lg border border-slate-300"
                  />
                </div>

                <!-- Story Rate -->
                <div>
                  <label class="block text-xs font-bold text-slate-700 mb-1" for="dash-rate-story">Rate per Story ($)</label>
                  <input
                    type="number"
                    id="dash-rate-story"
                    value="${creator ? creator.rateStory : 150}"
                    class="w-full text-sm p-2 rounded-lg border border-slate-300"
                  />
                </div>

                <!-- Bundle Rate -->
                <div>
                  <label class="block text-xs font-bold text-slate-700 mb-1" for="dash-rate-bundle">Content Bundle Rate ($)</label>
                  <input
                    type="number"
                    id="dash-rate-bundle"
                    value="${creator ? creator.bundleRate : 900}"
                    class="w-full text-sm p-2 rounded-lg border border-slate-300"
                  />
                </div>
              </div>

              <!-- Scope notes -->
              <div>
                <label class="block text-xs font-bold text-slate-700 mb-1" for="dash-notes">Deliverables & Usage Scope Notes</label>
                <textarea
                  id="dash-notes"
                  rows="3"
                  class="w-full text-sm p-2 rounded-lg border border-slate-300"
                >${this.escapeHtml(creator ? creator.deliverablesNote : '')}</textarea>
              </div>

              <!-- Availability Toggle -->
              <div class="pt-2">
                <label class="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    id="dash-open-collabs"
                    ${creator && creator.isOpenToCollabs ? 'checked' : ''}
                    class="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span class="text-sm font-semibold text-slate-800">Currently open to brand collaboration enquiries</span>
                </label>
              </div>

              <div class="pt-2">
                <button
                  type="submit"
                  class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Save Profile Changes
                </button>
              </div>
            </form>
          </div>

          <!-- Right Column: Live Directory Preview & Enquiries -->
          <div class="lg:col-span-5 space-y-6">
            <!-- Card Preview -->
            <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <span class="text-xs font-bold uppercase tracking-wider text-slate-400">Public Directory Preview</span>
              <h3 class="text-sm font-bold text-slate-800 mt-1 mb-4">How brands see your profile card</h3>
              ${creator ? this.renderCreatorCardHtml(creator) : '<p class="text-xs text-slate-400">No profile active.</p>'}
            </div>

            <!-- Received Brand Enquiries (Mediated) -->
            <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <div class="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 class="text-sm font-bold text-slate-900">Campaign Enquiries Routed to You</h3>
                <span class="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700">${enquiries.length} Enquiries</span>
              </div>

              <div class="mt-4 space-y-3">
                ${
                  enquiries.length > 0
                    ? enquiries.map(enq => `
                      <div class="p-3.5 rounded-xl border border-slate-200 bg-slate-50 text-xs space-y-1.5">
                        <div class="flex items-center justify-between">
                          <strong class="font-bold text-slate-900 text-sm">${this.escapeHtml(enq.brandName)}</strong>
                          <span class="px-2 py-0.5 rounded text-[10px] font-semibold ${
                            enq.status === 'intro_made'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-blue-100 text-blue-800'
                          }">
                            ${enq.status.replace('_', ' ').toUpperCase()}
                          </span>
                        </div>
                        <p class="text-slate-600">Campaign: <strong>${this.escapeHtml(enq.campaignName)}</strong></p>
                        <p class="text-slate-500">Budget: ${this.escapeHtml(enq.budgetRange)} | Deliverables: ${this.escapeHtml(enq.desiredContentType)}</p>
                        <p class="text-slate-700 pt-1 border-t border-slate-200 text-[11px]">
                          <strong>Mediator Status:</strong> ${this.escapeHtml(enq.coordinatorNotes || 'Under platform evaluation.')}
                        </p>
                      </div>
                    `).join('')
                    : `<p class="text-xs text-slate-500 py-4 text-center">No brand enquiries received yet. As brands send campaign requests, CollabPromo coordinates introductions here.</p>`
                }
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderBrandRegisterView() {
    return `
      <div class="py-10 px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto">
        <div class="mb-6">
          <a href="#home" class="text-xs font-semibold text-blue-600 hover:underline inline-flex items-center gap-1">&larr; Back to Home</a>
          <h1 class="mt-2 text-2xl sm:text-3xl font-extrabold text-slate-900">Brand & Marketer Registration</h1>
          <p class="mt-1 text-slate-600 text-sm">
            Create your brand account to search vetted creators, save shortlists, and submit structured campaign proposals.
          </p>
        </div>

        <form id="brand-register-form" class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6" novalidate>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <!-- Brand Name -->
            <div class="sm:col-span-2">
              <label class="block text-xs font-bold text-slate-700 mb-1" for="br-name">
                Brand or Company Name <span class="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="br-name"
                name="name"
                placeholder="e.g. Lumina Skin Co."
                class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                required
              />
              <div class="field-error-text hidden" id="err-br-name">Please enter your company or brand name.</div>
            </div>

            <!-- Contact Person -->
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1" for="br-contact">
                Contact Person Name <span class="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="br-contact"
                name="contactPerson"
                placeholder="e.g. Sarah Jenkins"
                class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                required
              />
              <div class="field-error-text hidden" id="err-br-contact">Please enter the contact person's name.</div>
            </div>

            <!-- Work Email -->
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1" for="br-email">
                Work Email Address <span class="text-red-500">*</span>
              </label>
              <input
                type="email"
                id="br-email"
                name="email"
                placeholder="sarah@luminaskin.com"
                class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                required
              />
              <div class="field-error-text hidden" id="err-br-email">Please enter a valid work email.</div>
            </div>

            <!-- Website / Social -->
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1" for="br-website">
                Website or Social Page
              </label>
              <input
                type="url"
                id="br-website"
                name="website"
                placeholder="https://luminaskin.example"
                class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <!-- Category -->
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1" for="br-category">
                Industry / Business Category <span class="text-red-500">*</span>
              </label>
              <select id="br-category" name="category" class="w-full text-sm p-2.5 rounded-lg border border-slate-300 bg-white" required>
                <option value="Beauty & Skincare">Beauty & Skincare</option>
                <option value="Consumer Tech & Hardware">Consumer Tech & Hardware</option>
                <option value="Fashion & Apparel">Fashion & Apparel</option>
                <option value="Health & Fitness">Health & Fitness</option>
                <option value="Food & Beverage">Food & Beverage</option>
                <option value="Software & Apps">Software & Apps</option>
                <option value="Travel & Hospitality">Travel & Hospitality</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <!-- Location -->
            <div class="sm:col-span-2">
              <label class="block text-xs font-bold text-slate-700 mb-1" for="br-location">
                Business Location (City, Country)
              </label>
              <input
                type="text"
                id="br-location"
                name="location"
                placeholder="e.g. New York, USA"
                class="w-full text-sm p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div class="pt-4 flex flex-col sm:flex-row items-center justify-end gap-3">
            <a href="#home" class="w-full sm:w-auto px-6 py-2.5 text-center text-sm font-semibold text-slate-600 hover:text-slate-900">
              Cancel
            </a>
            <button
              type="submit"
              class="w-full sm:w-auto px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-xl shadow-md transition-colors"
            >
              Complete Brand Registration
            </button>
          </div>
        </form>
      </div>
    `;
  }

  renderBrandDashboardView() {
    const currentUser = store.getCurrentUser();
    const brandEmail = currentUser.email || 's.jenkins@luminaskin.example';
    const brandName = currentUser.name || 'Lumina Skin Co.';
    const brandEnquiries = store.getEnquiriesForBrand(brandEmail);

    return `
      <div class="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
        <div class="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-200 gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-bold uppercase tracking-wider text-blue-600">Brand Campaign Center</span>
              <span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200">
                Verified Brand
              </span>
            </div>
            <h1 class="mt-1 text-2xl sm:text-3xl font-extrabold text-slate-900">
              Campaign Dashboard: ${this.escapeHtml(brandName)}
            </h1>
            <p class="mt-1 text-sm text-slate-500">
              Track the status of your campaign enquiries and platform-mediated creator introductions.
            </p>
          </div>

          <div class="flex items-center gap-3">
            <button id="btn-brand-new-enquiry" class="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg transition-colors flex items-center gap-2">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
              Submit New Campaign Brief
            </button>
          </div>
        </div>

        <!-- Enquiries List -->
        <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <div class="flex items-center justify-between pb-4 border-b border-slate-100">
            <h2 class="text-lg font-bold text-slate-900">Your Submitted Campaign Enquiries</h2>
            <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700">
              Total Enquiries: ${brandEnquiries.length}
            </span>
          </div>

          ${
            brandEnquiries.length > 0
              ? `
                <div class="mt-6 space-y-4">
                  ${brandEnquiries.map(enq => `
                    <div class="p-5 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors">
                      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200/80">
                        <div>
                          <div class="flex items-center gap-2">
                            <span class="font-mono text-xs font-bold text-blue-700">#${this.escapeHtml(enq.id)}</span>
                            <h3 class="font-bold text-slate-900 text-base">${this.escapeHtml(enq.campaignName)}</h3>
                          </div>
                          <p class="text-xs text-slate-500 mt-0.5">Submitted on ${new Date(enq.submittedAt).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <span class="px-3 py-1 rounded-full text-xs font-bold ${
                            enq.status === 'intro_made'
                              ? 'bg-emerald-100 text-emerald-800'
                              : enq.status === 'under_review'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-blue-100 text-blue-800'
                          }">
                            ${enq.status.replace('_', ' ').toUpperCase()}
                          </span>
                        </div>
                      </div>

                      <div class="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                        <div>
                          <span class="text-slate-400 block font-medium">Targeted Creator(s):</span>
                          <span class="font-semibold text-slate-800">${enq.selectedCreatorNames?.join(', ') || 'General Roster'}</span>
                        </div>
                        <div>
                          <span class="text-slate-400 block font-medium">Budget Range:</span>
                          <span class="font-semibold text-slate-800">${this.escapeHtml(enq.budgetRange)}</span>
                        </div>
                        <div>
                          <span class="text-slate-400 block font-medium">Content Type:</span>
                          <span class="font-semibold text-slate-800">${this.escapeHtml(enq.desiredContentType)}</span>
                        </div>
                        <div>
                          <span class="text-slate-400 block font-medium">Timeline:</span>
                          <span class="font-semibold text-slate-800">${this.escapeHtml(enq.timeline)}</span>
                        </div>
                      </div>

                      <div class="mt-3 p-3 bg-white rounded-lg border border-slate-200 text-xs">
                        <span class="font-bold text-slate-700">Coordinator Mediation Notes:</span>
                        <p class="text-slate-600 mt-0.5">${this.escapeHtml(enq.coordinatorNotes || 'Your enquiry has been received and is currently being evaluated against creator availability.')}</p>
                      </div>
                    </div>
                  `).join('')}
                </div>
              `
              : `
                <div class="text-center py-12">
                  <p class="text-sm text-slate-500">You haven't submitted any campaign enquiries yet.</p>
                  <a href="#directory" class="mt-4 inline-block px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg transition-colors">
                    Browse Creators to Send an Enquiry
                  </a>
                </div>
              `
          }
        </div>
      </div>
    `;
  }

  renderAdminPortalView() {
    const allCreators = store.getAllCreators();
    const allEnquiries = store.getAllEnquiries();

    return `
      <div class="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
        <!-- Admin Header -->
        <div class="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-200 gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
                Platform Administrator Area
              </span>
              <span class="text-xs text-slate-500 font-mono">Role: Mediator & Directory Manager</span>
            </div>
            <h1 class="mt-1 text-2xl sm:text-3xl font-extrabold text-slate-900">
              CollabPromo Administration & Moderation
            </h1>
            <p class="mt-1 text-sm text-slate-500">
              Review creator submissions, verify explicit consent status, approve or hide directory listings, and coordinate brand enquiries.
            </p>
          </div>

          <div class="flex flex-wrap items-center gap-2">
            <button id="btn-admin-reset-demo" class="px-3.5 py-2 text-xs font-semibold rounded-lg border border-red-300 text-red-700 hover:bg-red-50 transition-colors">
              Reset Demo Directory
            </button>
          </div>
        </div>

        <!-- Key Metrics Cards -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div class="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
            <span class="text-xs font-medium text-slate-500">Total Submissions</span>
            <span class="block text-2xl font-extrabold text-slate-900 mt-1">${allCreators.length}</span>
          </div>
          <div class="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
            <span class="text-xs font-medium text-slate-500">Active in Directory</span>
            <span class="block text-2xl font-extrabold text-emerald-600 mt-1">
              ${allCreators.filter(c => c.status === 'approved' && c.hasConsented).length}
            </span>
          </div>
          <div class="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
            <span class="text-xs font-medium text-slate-500">Pending Review</span>
            <span class="block text-2xl font-extrabold text-amber-600 mt-1">
              ${allCreators.filter(c => c.status === 'pending').length}
            </span>
          </div>
          <div class="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
            <span class="text-xs font-medium text-slate-500">Campaign Enquiries</span>
            <span class="block text-2xl font-extrabold text-blue-600 mt-1">${allEnquiries.length}</span>
          </div>
        </div>

        <!-- Tabs Section -->
        <div class="space-y-6">
          <!-- Section 1: Creator Directory Management -->
          <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div class="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h2 class="text-lg font-bold text-slate-900">Creator Directory Moderation</h2>
                <p class="text-xs text-slate-500 mt-0.5">Control directory visibility. Consent must be checked before a creator appears to brands.</p>
              </div>
            </div>

            <div class="mt-4 overflow-x-auto">
              <table class="w-full text-left text-xs">
                <thead>
                  <tr class="border-b border-slate-200 text-slate-400 uppercase font-semibold">
                    <th class="py-3 px-3">Creator / Handle</th>
                    <th class="py-3 px-3">Platform & Niche</th>
                    <th class="py-3 px-3">Followers</th>
                    <th class="py-3 px-3">Rates (Reel/Post)</th>
                    <th class="py-3 px-3">Consent Status</th>
                    <th class="py-3 px-3">Directory Visibility</th>
                    <th class="py-3 px-3 text-right">Moderator Actions</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                  ${allCreators.map(c => `
                    <tr class="hover:bg-slate-50/70 transition-colors">
                      <td class="py-3 px-3">
                        <div class="font-bold text-slate-900">${this.escapeHtml(c.name)}</div>
                        <div class="text-slate-400 font-mono text-[11px]">${this.escapeHtml(c.handle)}</div>
                        <div class="text-[10px] text-blue-600 font-mono mt-0.5">Contact: ${this.escapeHtml(c.privateEmail || 'Confidential')}</div>
                      </td>
                      <td class="py-3 px-3">
                        <div class="font-semibold text-slate-800">${this.escapeHtml(c.platform)}</div>
                        <div class="text-slate-500 text-[11px]">${this.escapeHtml(c.niche)}</div>
                      </td>
                      <td class="py-3 px-3 font-semibold text-slate-900">${this.formatNumber(c.followers)}</td>
                      <td class="py-3 px-3">
                        <span class="font-bold text-slate-900">${c.currencySymbol || '$'}${c.rateReel}</span>
                        <span class="text-slate-400"> / </span>
                        <span class="text-slate-600">${c.currencySymbol || '$'}${c.ratePost}</span>
                      </td>
                      <td class="py-3 px-3">
                        ${
                          c.hasConsented
                            ? `<span class="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-100 text-emerald-800">Consented</span>`
                            : `<span class="px-2 py-0.5 rounded text-[11px] font-semibold bg-red-100 text-red-800">No Consent</span>`
                        }
                      </td>
                      <td class="py-3 px-3">
                        <span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                          c.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : c.status === 'pending'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-200 text-slate-700'
                        }">
                          ${c.status.toUpperCase()}
                        </span>
                      </td>
                      <td class="py-3 px-3 text-right space-x-1 whitespace-nowrap">
                        ${
                          c.status !== 'approved'
                            ? `<button type="button" data-action="admin-approve" data-id="${c.id}" class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded text-[11px] transition-colors">Approve & Publish</button>`
                            : `<button type="button" data-action="admin-hide" data-id="${c.id}" class="px-2.5 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded text-[11px] transition-colors">Hide from Brands</button>`
                        }
                        <button type="button" data-action="admin-delete" data-id="${c.id}" class="px-2 py-1 text-red-600 hover:text-red-800 font-semibold text-[11px] hover:underline">
                          Delete
                        </button>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>

          <!-- Section 2: Brand Campaign Enquiries Coordinator Queue -->
          <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div class="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h2 class="text-lg font-bold text-slate-900">Campaign Enquiries & Mediation Pipeline</h2>
                <p class="text-xs text-slate-500 mt-0.5">Review incoming brand proposals, match with requested creators, and dispatch introductions.</p>
              </div>
            </div>

            <div class="mt-4 space-y-4">
              ${allEnquiries.map(enq => `
                <div class="p-4 rounded-xl border border-slate-200 bg-slate-50/70 text-xs space-y-3">
                  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div class="flex items-center gap-2">
                      <span class="font-mono font-bold text-blue-700">#${this.escapeHtml(enq.id)}</span>
                      <strong class="text-sm font-bold text-slate-900">${this.escapeHtml(enq.campaignName)}</strong>
                      <span class="text-slate-400">by</span>
                      <span class="font-semibold text-slate-800">${this.escapeHtml(enq.brandName)} (${this.escapeHtml(enq.contactPerson)})</span>
                    </div>
                    <div class="flex items-center gap-2">
                      <label class="text-[11px] font-semibold text-slate-500">Status:</label>
                      <select data-action="admin-change-enq-status" data-id="${enq.id}" class="text-xs py-1 px-2 rounded border border-slate-300 bg-white font-semibold">
                        <option value="submitted" ${enq.status === 'submitted' ? 'selected' : ''}>Submitted</option>
                        <option value="under_review" ${enq.status === 'under_review' ? 'selected' : ''}>Under Review</option>
                        <option value="intro_made" ${enq.status === 'intro_made' ? 'selected' : ''}>Intro Made</option>
                        <option value="closed" ${enq.status === 'closed' ? 'selected' : ''}>Closed</option>
                      </select>
                    </div>
                  </div>

                  <div class="grid grid-cols-1 sm:grid-cols-4 gap-2 text-[11px] bg-white p-3 rounded-lg border border-slate-200">
                    <div>
                      <span class="text-slate-400 block">Brand Email:</span>
                      <span class="font-mono text-slate-800">${this.escapeHtml(enq.workEmail)}</span>
                    </div>
                    <div>
                      <span class="text-slate-400 block">Requested Creator(s):</span>
                      <span class="font-semibold text-slate-800">${enq.selectedCreatorNames?.join(', ') || 'General Roster'}</span>
                    </div>
                    <div>
                      <span class="text-slate-400 block">Budget & Content:</span>
                      <span class="font-semibold text-slate-800">${this.escapeHtml(enq.budgetRange)} — ${this.escapeHtml(enq.desiredContentType)}</span>
                    </div>
                    <div>
                      <span class="text-slate-400 block">Usage Rights:</span>
                      <span class="font-semibold text-slate-800">${this.escapeHtml(enq.usageRights || 'Organic')}</span>
                    </div>
                  </div>

                  <!-- Coordinator Notes field -->
                  <div>
                    <label class="block text-[11px] font-semibold text-slate-600 mb-1">Coordinator Notes & Action Log:</label>
                    <div class="flex items-center gap-2">
                      <input
                        type="text"
                        id="coord-note-${enq.id}"
                        value="${this.escapeHtml(enq.coordinatorNotes || '')}"
                        placeholder="e.g. Budget matches creator rates. Intro email prepared."
                        class="flex-1 text-xs p-2 rounded border border-slate-300 bg-white"
                      />
                      <button
                        type="button"
                        data-action="admin-save-note"
                        data-id="${enq.id}"
                        class="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded text-xs transition-colors"
                      >
                        Save Note
                      </button>
                    </div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderAboutView() {
    return `
      <div class="py-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-8">
        <div>
          <span class="text-xs font-bold uppercase tracking-wider text-blue-600">About Our Platform</span>
          <h1 class="mt-1 text-3xl font-extrabold text-slate-900">About CollabPromo.com</h1>
          <p class="mt-2 text-slate-600 text-base leading-relaxed">
            CollabPromo.com was built to solve the frustration of opaque pricing, cold email spam, and uncoordinated brand deals in the influencer and creator marketing space.
          </p>
        </div>

        <div class="space-y-6 text-slate-700 text-sm leading-relaxed">
          <div class="p-6 bg-white rounded-2xl border border-slate-200">
            <h2 class="text-lg font-bold text-slate-900 mb-2">Our Role as Platform Mediator</h2>
            <p>
              Rather than leaving creators to deal with unsolicited lowball DMs and brands to guess rate cards through layers of agency gatekeepers, CollabPromo provides a clean, transparent directory.
            </p>
            <p class="mt-2">
              Creators explicitly share their baseline commercial rates for reels, videos, posts, and story integrations. Brands submit structured campaign proposals, and CollabPromo coordinates the introduction to ensure deliverables, timing, and budgets match expectations before contracts are signed.
            </p>
          </div>

          <div class="p-6 bg-white rounded-2xl border border-slate-200">
            <h2 class="text-lg font-bold text-slate-900 mb-2">Our Core Principles</h2>
            <ul class="list-disc pl-5 space-y-2 mt-2">
              <li><strong>Zero Direct Email Scraping:</strong> We shield creator personal contact details to maintain privacy and focus.</li>
              <li><strong>Transparent Rate Cards:</strong> Transparent baseline expectations save weeks of back-and-forth negotiations.</li>
              <li><strong>Honest Availability:</strong> Creators can pause or update their availability at any time without penalty.</li>
              <li><strong>No False Promises:</strong> Submitting a profile or campaign enquiry does not guarantee placement until both parties formally confirm.</li>
            </ul>
          </div>
        </div>
      </div>
    `;
  }

  renderPrivacyView() {
    return `
      <div class="py-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-8">
        <div>
          <span class="text-xs font-bold uppercase tracking-wider text-blue-600">Legal & Privacy</span>
          <h1 class="mt-1 text-3xl font-extrabold text-slate-900">Privacy Policy</h1>
          <p class="mt-1 text-slate-500 text-xs">Last updated: November 2026</p>
        </div>

        <div class="p-6 bg-white rounded-2xl border border-slate-200 space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <h2 class="text-base font-bold text-slate-900">1. Information We Collect</h2>
          <p>
            <strong>For Creators:</strong> We collect channel handles, public profile links, niche categories, follower counts, and self-reported commercial rates. We also collect your private email and preferred contact details solely for platform mediation and communication.
          </p>
          <p>
            <strong>For Brands:</strong> We collect company names, contact person details, work emails, campaign objectives, and estimated budgets.
          </p>

          <h2 class="text-base font-bold text-slate-900 pt-3 border-t border-slate-100">2. Creator Contact Shielding</h2>
          <p>
            We strictly protect creator privacy. Your personal email address and phone number are <strong>never</strong> displayed in the brand-facing directory, nor sold to third parties. Brands must send campaign enquiries through CollabPromo.
          </p>

          <h2 class="text-base font-bold text-slate-900 pt-3 border-t border-slate-100">3. Explicit Consent Requirement</h2>
          <p>
            A creator's profile, follower statistics, and rates will only appear in the directory if the creator has provided explicit consent via our onboarding form. Consent can be revoked or paused at any time by updating your dashboard settings or contacting support.
          </p>

          <h2 class="text-base font-bold text-slate-900 pt-3 border-t border-slate-100">4. Data Storage & Security</h2>
          <p>
            Data is securely stored and processed in compliance with modern privacy standards. We do not collect or request your social media passwords, private analytics tokens, or financial accounts.
          </p>
        </div>
      </div>
    `;
  }

  renderTermsView() {
    return `
      <div class="py-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-8">
        <div>
          <span class="text-xs font-bold uppercase tracking-wider text-blue-600">Platform Terms</span>
          <h1 class="mt-1 text-3xl font-extrabold text-slate-900">Terms of Service</h1>
          <p class="mt-1 text-slate-500 text-xs">Last updated: November 2026</p>
        </div>

        <div class="p-6 bg-white rounded-2xl border border-slate-200 space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <h2 class="text-base font-bold text-slate-900">1. Platform Mediation Model</h2>
          <p>
            CollabPromo.com acts strictly as an introductory mediation platform connecting independent social media creators and commercial brands. CollabPromo is not an employer, talent agency, or talent representative.
          </p>

          <h2 class="text-base font-bold text-slate-900 pt-3 border-t border-slate-100">2. No Guarantee of Brand Deals or Results</h2>
          <p>
            Submitting a creator profile does not guarantee that any brand will contact you or sponsor your content. Similarly, CollabPromo does not guarantee specific campaign performance, audience conversions, or view metrics for brands.
          </p>

          <h2 class="text-base font-bold text-slate-900 pt-3 border-t border-slate-100">3. Nature of Campaign Enquiries</h2>
          <p>
            A campaign enquiry submitted through CollabPromo is an exploratory request for introduction. It does not constitute a legally binding advertising contract or confirmed booking until both the creator and the brand agree to terms and deliverables.
          </p>

          <h2 class="text-base font-bold text-slate-900 pt-3 border-t border-slate-100">4. Content Standards & Prohibited Niches</h2>
          <p>
            We do not facilitate campaigns involving deceptive advertising, illegal goods, hate speech, unverified financial schemes, or non-compliant undisclosed sponsorship arrangements.
          </p>
        </div>
      </div>
    `;
  }

  // ==========================================
  // EVENT BINDINGS
  // ==========================================

  setupGlobalEvents() {
    // Role switcher modal open buttons
    document.querySelectorAll('[data-action="open-role-switcher"]').forEach(btn => {
      btn.addEventListener('click', () => this.openRoleSwitcherModal());
    });

    // Mobile menu toggle
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenuBtn && mobileMenu) {
      mobileMenuBtn.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
      });
    }

    // Role switcher option clicks inside modal
    document.addEventListener('click', (e) => {
      const target = e.target.closest('[data-switch-role]');
      if (target) {
        const role = target.getAttribute('data-switch-role');
        if (role === 'guest') {
          store.logout();
          this.showToast('Switched to Visitor / Guest view');
          this.navigateTo('home');
        } else if (role === 'creator') {
          store.login('creator', { id: 'cr-1' });
          this.showToast('Logged in as Creator: Maya Lin');
          this.navigateTo('creator-dashboard');
        } else if (role === 'brand') {
          store.login('brand', { id: 'br-1' });
          this.showToast('Logged in as Brand: Lumina Skin Co.');
          this.navigateTo('directory');
        } else if (role === 'admin') {
          store.login('admin');
          this.showToast('Entered Platform Admin Portal');
          this.navigateTo('admin-portal');
        }
        this.closeModal();
      }
    });

    // Sign out button
    const btnSignOut = document.getElementById('btn-signout');
    if (btnSignOut) {
      btnSignOut.addEventListener('click', () => {
        store.logout();
        this.showToast('You have been signed out.');
        this.navigateTo('home');
      });
    }

    // Modal background close
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.activeModal) {
        this.closeModal();
      }
    });

    // Delegated actions for creator cards (View Profile, Request Enquiry)
    document.addEventListener('click', (e) => {
      const viewProfileBtn = e.target.closest('[data-action="view-profile"]');
      if (viewProfileBtn) {
        const creatorId = viewProfileBtn.getAttribute('data-creator-id');
        this.openCreatorDetailModal(creatorId);
        return;
      }

      const enquireBtn = e.target.closest('[data-action="enquire-creator"]');
      if (enquireBtn) {
        const creatorId = enquireBtn.getAttribute('data-creator-id');
        this.openCampaignEnquiryModal(creatorId);
        return;
      }

      const modalCloseBtn = e.target.closest('[data-action="close-modal"]');
      if (modalCloseBtn) {
        this.closeModal();
        return;
      }
    });
  }

  bindHomeEvents() {
    const btnBrandRole = document.getElementById('hero-btn-brand-role');
    const btnCreatorRole = document.getElementById('hero-btn-creator-role');
    const btnLoginDemoCreator = document.getElementById('btn-login-demo-creator');

    if (btnBrandRole) {
      btnBrandRole.addEventListener('click', () => {
        this.navigateTo('directory');
      });
    }

    if (btnCreatorRole) {
      btnCreatorRole.addEventListener('click', () => {
        this.navigateTo('creator-register');
      });
    }

    if (btnLoginDemoCreator) {
      btnLoginDemoCreator.addEventListener('click', () => {
        store.login('creator', { id: 'cr-1' });
        this.showToast('Logged in as Demo Creator: Maya Lin');
        this.navigateTo('creator-dashboard');
      });
    }
  }

  bindDirectoryEvents() {
    const searchInput = document.getElementById('directory-search');
    const nicheSelect = document.getElementById('filter-niche');
    const followersSelect = document.getElementById('filter-followers');
    const reelRateSelect = document.getElementById('filter-reel-rate');
    const sortSelect = document.getElementById('filter-sort');
    const openCollabsCheck = document.getElementById('filter-open-collabs');
    const resetBtn = document.getElementById('btn-reset-filters');
    const emptyResetBtn = document.getElementById('btn-empty-reset');
    const quickEnquiryBtn = document.getElementById('btn-quick-enquiry');

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.filters.search = e.target.value;
        this.renderDirectoryGridOnly();
      });
    }

    // Platform filter pills
    document.querySelectorAll('.platform-filter-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        this.filters.platform = pill.getAttribute('data-platform');
        this.renderCurrentView();
      });
    });

    if (nicheSelect) {
      nicheSelect.addEventListener('change', (e) => {
        this.filters.niche = e.target.value;
        this.renderDirectoryGridOnly();
      });
    }

    if (followersSelect) {
      followersSelect.addEventListener('change', (e) => {
        const val = e.target.value;
        if (val === 'micro') {
          this.filters.minFollowers = null;
          this.filters.maxFollowers = 50000;
        } else if (val === 'mid') {
          this.filters.minFollowers = 50000;
          this.filters.maxFollowers = 200000;
        } else if (val === 'macro') {
          this.filters.minFollowers = 200000;
          this.filters.maxFollowers = null;
        } else {
          this.filters.minFollowers = null;
          this.filters.maxFollowers = null;
        }
        this.renderDirectoryGridOnly();
      });
    }

    if (reelRateSelect) {
      reelRateSelect.addEventListener('change', (e) => {
        const val = e.target.value;
        this.filters.maxRateReel = val === 'all' ? null : parseFloat(val);
        this.renderDirectoryGridOnly();
      });
    }

    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        this.filters.sortBy = e.target.value;
        this.renderDirectoryGridOnly();
      });
    }

    if (openCollabsCheck) {
      openCollabsCheck.addEventListener('change', (e) => {
        this.filters.openToCollabsOnly = e.target.checked;
        this.renderDirectoryGridOnly();
      });
    }

    const resetAction = () => {
      this.filters = {
        search: '',
        platform: 'all',
        niche: 'All Categories',
        location: '',
        minFollowers: null,
        maxFollowers: null,
        minRateReel: null,
        maxRateReel: null,
        minRatePost: null,
        maxRatePost: null,
        openToCollabsOnly: false,
        sortBy: 'followers_desc'
      };
      this.renderCurrentView();
      this.showToast('Filters reset to default.');
    };

    if (resetBtn) resetBtn.addEventListener('click', resetAction);
    if (emptyResetBtn) emptyResetBtn.addEventListener('click', resetAction);

    if (quickEnquiryBtn) {
      quickEnquiryBtn.addEventListener('click', () => {
        this.openCampaignEnquiryModal(null);
      });
    }
  }

  renderDirectoryGridOnly() {
    // Fast re-render of directory view without tearing down search focus
    const publicCreators = store.getPublicCreators();
    const filteredCreators = this.applyFilters(publicCreators);
    const container = document.querySelector('.creator-card')?.parentElement || document.querySelector('#btn-empty-reset')?.parentElement?.parentElement;
    
    // Simple re-render of whole view while preserving search input cursor
    const searchVal = document.getElementById('directory-search')?.value || '';
    const mainContent = document.getElementById('app-main-content');
    if (mainContent && this.currentView === 'directory') {
      mainContent.innerHTML = this.renderDirectoryView();
      this.bindDirectoryEvents();
      const newSearch = document.getElementById('directory-search');
      if (newSearch) {
        newSearch.value = searchVal;
        newSearch.focus();
        newSearch.setSelectionRange(searchVal.length, searchVal.length);
      }
    }
  }

  bindCreatorRegisterEvents() {
    const form = document.getElementById('creator-register-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let isValid = true;

      // Validate Name
      const nameInput = document.getElementById('cr-name');
      const errName = document.getElementById('err-cr-name');
      if (!nameInput.value.trim()) {
        nameInput.classList.add('field-error-input');
        errName.classList.remove('hidden');
        isValid = false;
      } else {
        nameInput.classList.remove('field-error-input');
        errName.classList.add('hidden');
      }

      // Validate Email
      const emailInput = document.getElementById('cr-email');
      const errEmail = document.getElementById('err-cr-email');
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailInput.value.trim() || !emailRegex.test(emailInput.value.trim())) {
        emailInput.classList.add('field-error-input');
        errEmail.classList.remove('hidden');
        isValid = false;
      } else {
        emailInput.classList.remove('field-error-input');
        errEmail.classList.add('hidden');
      }

      // Validate Handle
      const handleInput = document.getElementById('cr-handle');
      const errHandle = document.getElementById('err-cr-handle');
      if (!handleInput.value.trim()) {
        handleInput.classList.add('field-error-input');
        errHandle.classList.remove('hidden');
        isValid = false;
      } else {
        handleInput.classList.remove('field-error-input');
        errHandle.classList.add('hidden');
      }

      // Validate Profile URL
      const urlInput = document.getElementById('cr-profile-url');
      const errUrl = document.getElementById('err-cr-url');
      if (!urlInput.value.trim() || !urlInput.value.startsWith('http')) {
        urlInput.classList.add('field-error-input');
        errUrl.classList.remove('hidden');
        isValid = false;
      } else {
        urlInput.classList.remove('field-error-input');
        errUrl.classList.add('hidden');
      }

      // Validate Location
      const locInput = document.getElementById('cr-location');
      const errLoc = document.getElementById('err-cr-location');
      if (!locInput.value.trim()) {
        locInput.classList.add('field-error-input');
        errLoc.classList.remove('hidden');
        isValid = false;
      } else {
        locInput.classList.remove('field-error-input');
        errLoc.classList.add('hidden');
      }

      // Validate Followers
      const followersInput = document.getElementById('cr-followers');
      const errFollowers = document.getElementById('err-cr-followers');
      if (!followersInput.value || parseInt(followersInput.value, 10) < 10) {
        followersInput.classList.add('field-error-input');
        errFollowers.classList.remove('hidden');
        isValid = false;
      } else {
        followersInput.classList.remove('field-error-input');
        errFollowers.classList.add('hidden');
      }

      // Validate Rate Reel
      const rateReelInput = document.getElementById('cr-rate-reel');
      const errRateReel = document.getElementById('err-cr-rate-reel');
      if (!rateReelInput.value || parseFloat(rateReelInput.value) <= 0) {
        rateReelInput.classList.add('field-error-input');
        errRateReel.classList.remove('hidden');
        isValid = false;
      } else {
        rateReelInput.classList.remove('field-error-input');
        errRateReel.classList.add('hidden');
      }

      // Validate Rate Post
      const ratePostInput = document.getElementById('cr-rate-post');
      const errRatePost = document.getElementById('err-cr-rate-post');
      if (!ratePostInput.value || parseFloat(ratePostInput.value) <= 0) {
        ratePostInput.classList.add('field-error-input');
        errRatePost.classList.remove('hidden');
        isValid = false;
      } else {
        ratePostInput.classList.remove('field-error-input');
        errRatePost.classList.add('hidden');
      }

      // Validate Consent Checkbox
      const consentCheck = document.getElementById('cr-consent');
      const errConsent = document.getElementById('err-cr-consent');
      if (!consentCheck.checked) {
        errConsent.classList.remove('hidden');
        isValid = false;
      } else {
        errConsent.classList.add('hidden');
      }

      if (!isValid) {
        this.showToast('Please fix the highlighted errors before submitting.', 'error');
        return;
      }

      // Collect data and create creator profile
      const formData = new FormData(form);
      const creatorPayload = {
        name: formData.get('name'),
        privateEmail: formData.get('privateEmail'),
        preferredContact: formData.get('preferredContact'),
        privatePhone: formData.get('privatePhone'),
        platform: formData.get('platform'),
        handle: formData.get('handle'),
        profileUrl: formData.get('profileUrl'),
        niche: formData.get('niche'),
        location: formData.get('location'),
        followers: formData.get('followers'),
        avgViews: formData.get('avgViews'),
        bio: formData.get('bio'),
        currency: formData.get('currency'),
        rateReel: formData.get('rateReel'),
        ratePost: formData.get('ratePost'),
        rateStory: formData.get('rateStory'),
        bundleRate: formData.get('bundleRate'),
        deliverablesNote: formData.get('deliverablesNote'),
        isOpenToCollabs: formData.get('isOpenToCollabs') !== null,
        hasConsented: formData.get('hasConsented') !== null
      };

      const newCreator = store.addCreator(creatorPayload);
      store.login('creator', newCreator);

      this.showToast('Creator profile successfully submitted and published to directory!');
      this.navigateTo('creator-dashboard');
    });
  }

  bindCreatorDashboardEvents() {
    const form = document.getElementById('creator-update-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const id = document.getElementById('edit-creator-id').value;
      if (!id) return;

      const updates = {
        followers: parseInt(document.getElementById('dash-followers').value, 10) || 0,
        avgViews: parseInt(document.getElementById('dash-views').value, 10) || 0,
        rateReel: parseFloat(document.getElementById('dash-rate-reel').value) || 0,
        ratePost: parseFloat(document.getElementById('dash-rate-post').value) || 0,
        rateStory: parseFloat(document.getElementById('dash-rate-story').value) || 0,
        bundleRate: parseFloat(document.getElementById('dash-rate-bundle').value) || 0,
        deliverablesNote: document.getElementById('dash-notes').value.trim(),
        isOpenToCollabs: document.getElementById('dash-open-collabs').checked
      };

      store.updateCreator(id, updates);
      this.showToast('Your rate card and profile details have been saved!');
    });

    const btnTopSave = document.getElementById('btn-save-creator-dashboard');
    if (btnTopSave) {
      btnTopSave.addEventListener('click', () => {
        form.requestSubmit();
      });
    }
  }

  bindBrandRegisterEvents() {
    const form = document.getElementById('brand-register-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let isValid = true;

      const nameInput = document.getElementById('br-name');
      const errName = document.getElementById('err-br-name');
      if (!nameInput.value.trim()) {
        nameInput.classList.add('field-error-input');
        errName.classList.remove('hidden');
        isValid = false;
      } else {
        nameInput.classList.remove('field-error-input');
        errName.classList.add('hidden');
      }

      const contactInput = document.getElementById('br-contact');
      const errContact = document.getElementById('err-br-contact');
      if (!contactInput.value.trim()) {
        contactInput.classList.add('field-error-input');
        errContact.classList.remove('hidden');
        isValid = false;
      } else {
        contactInput.classList.remove('field-error-input');
        errContact.classList.add('hidden');
      }

      const emailInput = document.getElementById('br-email');
      const errEmail = document.getElementById('err-br-email');
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailInput.value.trim() || !emailRegex.test(emailInput.value.trim())) {
        emailInput.classList.add('field-error-input');
        errEmail.classList.remove('hidden');
        isValid = false;
      } else {
        emailInput.classList.remove('field-error-input');
        errEmail.classList.add('hidden');
      }

      if (!isValid) {
        this.showToast('Please complete the required fields.', 'error');
        return;
      }

      const brand = store.addBrand({
        name: nameInput.value,
        contactPerson: contactInput.value,
        email: emailInput.value,
        website: document.getElementById('br-website').value,
        category: document.getElementById('br-category').value,
        location: document.getElementById('br-location').value
      });

      store.login('brand', brand);
      this.showToast(`Welcome ${brand.name}! You are now registered.`);
      this.navigateTo('directory');
    });
  }

  bindBrandDashboardEvents() {
    const btnNewEnquiry = document.getElementById('btn-brand-new-enquiry');
    if (btnNewEnquiry) {
      btnNewEnquiry.addEventListener('click', () => {
        this.openCampaignEnquiryModal(null);
      });
    }
  }

  bindAdminPortalEvents() {
    const resetDemoBtn = document.getElementById('btn-admin-reset-demo');
    if (resetDemoBtn) {
      resetDemoBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to reset all creator profiles and enquiries back to the initial demo roster?')) {
          store.resetToDemoData();
          this.showToast('Demo directory and enquiries have been reset.');
        }
      });
    }

    // Admin approve action
    document.querySelectorAll('[data-action="admin-approve"]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        store.setCreatorStatus(id, 'approved');
        this.showToast('Creator approved and published to Brand Directory.');
      });
    });

    // Admin hide action
    document.querySelectorAll('[data-action="admin-hide"]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        store.setCreatorStatus(id, 'hidden');
        this.showToast('Creator profile hidden from public brand discovery.');
      });
    });

    // Admin delete action
    document.querySelectorAll('[data-action="admin-delete"]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        if (confirm('Permanently delete this creator listing?')) {
          store.deleteCreator(id);
          this.showToast('Listing removed.');
        }
      });
    });

    // Admin status change for enquiries
    document.querySelectorAll('[data-action="admin-change-enq-status"]').forEach(select => {
      select.addEventListener('change', (e) => {
        const id = select.getAttribute('data-id');
        store.updateEnquiryStatus(id, e.target.value);
        this.showToast(`Enquiry #${id} status updated to ${e.target.value}`);
      });
    });

    // Admin note save for enquiries
    document.querySelectorAll('[data-action="admin-save-note"]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        const noteInput = document.getElementById(`coord-note-${id}`);
        if (noteInput) {
          store.updateEnquiryStatus(id, store.enquiries.find(e => e.id === id)?.status || 'under_review', noteInput.value.trim());
          this.showToast(`Coordinator note saved for enquiry #${id}`);
        }
      });
    });
  }

  // ==========================================
  // MODALS & DIALOGS
  // ==========================================

  openCreatorDetailModal(creatorId) {
    const creator = store.getCreatorById(creatorId, false);
    if (!creator) return;

    this.selectedCreatorForModal = creator;
    const modalContainer = document.getElementById('modal-container');
    if (!modalContainer) return;

    modalContainer.innerHTML = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 modal-backdrop overflow-y-auto">
        <div class="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative modal-content my-8 max-h-[90vh] overflow-y-auto" role="dialog" aria-modal="true" aria-labelledby="modal-creator-name">
          <!-- Close Button -->
          <button data-action="close-modal" class="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-2 rounded-lg" aria-label="Close modal">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>

          <!-- Header info -->
          <div class="flex items-start gap-4 pr-10">
            <img
              src="${this.escapeHtml(creator.avatar)}"
              alt="${this.escapeHtml(creator.name)}"
              class="w-16 h-16 sm:w-20 sm:h-20 rounded-full object-cover border border-slate-200"
            />
            <div>
              <div class="flex items-center gap-2">
                <span class="px-2.5 py-0.5 rounded text-xs font-semibold ${
                  creator.platform === 'Instagram'
                    ? 'badge-instagram'
                    : creator.platform === 'YouTube'
                    ? 'badge-youtube'
                    : 'badge-tiktok'
                }">
                  ${this.escapeHtml(creator.platform)}
                </span>
                <span class="text-xs text-slate-500 font-medium">${this.escapeHtml(creator.location)}</span>
              </div>
              <h2 id="modal-creator-name" class="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1">
                ${this.escapeHtml(creator.name)}
              </h2>
              <a
                href="${this.escapeHtml(creator.profileUrl)}"
                target="_blank"
                rel="noopener noreferrer"
                class="text-xs text-blue-600 hover:underline font-mono inline-flex items-center gap-1 mt-0.5"
              >
                ${this.escapeHtml(creator.handle)}
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
              </a>
            </div>
          </div>

          <!-- Bio -->
          <div class="mt-5 p-4 rounded-xl bg-slate-50 border border-slate-100 text-sm text-slate-700">
            <span class="font-bold text-xs uppercase tracking-wider text-slate-400 block mb-1">Creator Profile</span>
            <p>${this.escapeHtml(creator.bio || 'Authentic content creator specializing in dedicated audience engagement.')}</p>
          </div>

          <!-- Audience Snapshot -->
          <div class="mt-4 grid grid-cols-2 gap-3 text-center">
            <div class="p-3 bg-blue-50/60 rounded-xl border border-blue-100">
              <span class="text-xs text-slate-500 uppercase font-medium">Followers / Audience</span>
              <span class="block text-lg font-bold text-slate-900 mt-0.5">${this.formatNumber(creator.followers)}</span>
            </div>
            <div class="p-3 bg-blue-50/60 rounded-xl border border-blue-100">
              <span class="text-xs text-slate-500 uppercase font-medium">Average Video Views</span>
              <span class="block text-lg font-bold text-slate-900 mt-0.5">${creator.avgViews ? this.formatNumber(creator.avgViews) : 'Available on request'}</span>
            </div>
          </div>

          <!-- Full Commercial Rate Card -->
          <div class="mt-6 border-t border-slate-200 pt-5">
            <h3 class="text-sm font-bold uppercase tracking-wider text-slate-900 mb-3">Commercial Rate Card (USD)</h3>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div class="p-3.5 rounded-xl border border-slate-200 text-center">
                <span class="text-xs text-slate-500 font-medium">Reel / Video</span>
                <span class="block text-lg font-extrabold text-slate-900 mt-1">${creator.currencySymbol || '$'}${creator.rateReel}</span>
                <span class="text-[11px] text-slate-400">Vertical 9:16 format</span>
              </div>
              <div class="p-3.5 rounded-xl border border-slate-200 text-center">
                <span class="text-xs text-slate-500 font-medium">Static Feed Post</span>
                <span class="block text-lg font-extrabold text-slate-900 mt-1">${creator.currencySymbol || '$'}${creator.ratePost}</span>
                <span class="text-[11px] text-slate-400">High-res carousel / image</span>
              </div>
              <div class="p-3.5 rounded-xl border border-slate-200 text-center">
                <span class="text-xs text-slate-500 font-medium">Content Bundle</span>
                <span class="block text-lg font-extrabold text-blue-700 mt-1">${creator.bundleRate ? `${creator.currencySymbol || '$'}${creator.bundleRate}` : 'Custom'}</span>
                <span class="text-[11px] text-slate-400">Reel + Story + Deliverables</span>
              </div>
            </div>

            <!-- Deliverables & revisions note -->
            <div class="mt-4 text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <strong>Deliverables Scope & Terms:</strong>
              <p class="mt-1">${this.escapeHtml(creator.deliverablesNote || 'Standard deliverables include 1 round of revisions and 30-day organic posting rights.')}</p>
            </div>
          </div>

          <!-- Privacy Shield Notice -->
          <div class="mt-5 p-3 rounded-xl mediator-notice text-xs text-slate-700">
            <span class="font-bold text-slate-900">Direct Contact Information Shielded:</span>
            To prevent spam, creator email addresses and phone numbers are not shown. When you submit a campaign enquiry below, CollabPromo coordinates directly with ${this.escapeHtml(creator.name)}.
          </div>

          <!-- Action Buttons -->
          <div class="mt-6 flex flex-col sm:flex-row items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button data-action="close-modal" class="w-full sm:w-auto px-5 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900">
              Close Profile
            </button>
            <button
              id="btn-modal-enquire-creator"
              class="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors"
            >
              Send Campaign Enquiry for ${this.escapeHtml(creator.name)}
            </button>
          </div>
        </div>
      </div>
    `;

    document.getElementById('btn-modal-enquire-creator')?.addEventListener('click', () => {
      this.closeModal();
      this.openCampaignEnquiryModal(creator.id);
    });

    this.activeModal = 'creator-detail';
  }

  openCampaignEnquiryModal(preselectedCreatorId = null) {
    const creators = store.getPublicCreators();
    const currentUser = store.getCurrentUser();
    const modalContainer = document.getElementById('modal-container');
    if (!modalContainer) return;

    const preselectedCreator = preselectedCreatorId ? store.getCreatorById(preselectedCreatorId, false) : null;

    modalContainer.innerHTML = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 modal-backdrop overflow-y-auto">
        <div class="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative modal-content my-8 max-h-[90vh] overflow-y-auto" role="dialog" aria-modal="true">
          <!-- Close button -->
          <button data-action="close-modal" class="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-2 rounded-lg" aria-label="Close modal">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>

          <div class="mb-5 pr-8">
            <span class="text-xs font-bold uppercase tracking-wider text-blue-600">Mediated Brief Submission</span>
            <h2 class="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1">
              ${preselectedCreator ? `Campaign Enquiry: ${this.escapeHtml(preselectedCreator.name)}` : 'Submit Campaign Enquiry'}
            </h2>
            <p class="text-xs text-slate-500 mt-1">
              CollabPromo reviews your campaign objectives and coordinates introductions with qualified creators. (Note: Submitting an enquiry is an introductory request, not a confirmed booking).
            </p>
          </div>

          <form id="campaign-enquiry-form" class="space-y-4 text-xs" novalidate>
            <!-- Brand Info Row -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label class="block font-bold text-slate-700 mb-1" for="enq-brand-name">
                  Brand / Company Name <span class="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="enq-brand-name"
                  name="brandName"
                  value="${currentUser.role === 'brand' ? this.escapeHtml(currentUser.name || '') : ''}"
                  placeholder="e.g. Lumina Skin Co."
                  class="w-full p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-enq-brand">Please enter your company name.</div>
              </div>

              <div>
                <label class="block font-bold text-slate-700 mb-1" for="enq-contact-person">
                  Contact Person <span class="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="enq-contact-person"
                  name="contactPerson"
                  value="${currentUser.role === 'brand' ? this.escapeHtml(currentUser.contactPerson || '') : ''}"
                  placeholder="e.g. Sarah Jenkins"
                  class="w-full p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-enq-contact">Please enter the contact person.</div>
              </div>

              <div>
                <label class="block font-bold text-slate-700 mb-1" for="enq-work-email">
                  Work Email Address <span class="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  id="enq-work-email"
                  name="workEmail"
                  value="${currentUser.role === 'brand' ? this.escapeHtml(currentUser.email || '') : ''}"
                  placeholder="sarah@luminaskin.example"
                  class="w-full p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-enq-email">Please enter a valid work email.</div>
              </div>

              <div>
                <label class="block font-bold text-slate-700 mb-1" for="enq-creator-target">
                  Target Creator Profile
                </label>
                <select id="enq-creator-target" name="selectedCreatorId" class="w-full p-2.5 rounded-lg border border-slate-300 bg-white">
                  <option value="">General Roster (CollabPromo will recommend fits)</option>
                  ${creators.map(c => `
                    <option value="${c.id}" ${preselectedCreatorId === c.id ? 'selected' : ''}>
                      ${c.name} (${c.handle} - ${c.platform})
                    </option>
                  `).join('')}
                </select>
              </div>
            </div>

            <!-- Campaign Specifics -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
              <div>
                <label class="block font-bold text-slate-700 mb-1" for="enq-campaign-name">
                  Campaign / Product Name <span class="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="enq-campaign-name"
                  name="campaignName"
                  placeholder="e.g. Summer Skincare Serum Launch"
                  class="w-full p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  required
                />
                <div class="field-error-text hidden" id="err-enq-campaign">Please specify the campaign name.</div>
              </div>

              <div>
                <label class="block font-bold text-slate-700 mb-1" for="enq-goal">
                  Primary Campaign Goal
                </label>
                <select id="enq-goal" name="campaignGoal" class="w-full p-2.5 rounded-lg border border-slate-300 bg-white">
                  <option value="Brand Awareness">Brand Awareness</option>
                  <option value="Product Launch & Reviews">Product Launch & Reviews</option>
                  <option value="Conversions & Direct Sales">Conversions & Direct Sales</option>
                  <option value="Creative Asset Generation">Creative Asset Generation</option>
                </select>
              </div>

              <div>
                <label class="block font-bold text-slate-700 mb-1" for="enq-content-type">
                  Desired Content Type <span class="text-red-500">*</span>
                </label>
                <select id="enq-content-type" name="desiredContentType" class="w-full p-2.5 rounded-lg border border-slate-300 bg-white">
                  <option value="Reel / Short Video (9:16)">Reel / Short Video (9:16)</option>
                  <option value="Dedicated Long Video (YouTube)">Dedicated Long Video (YouTube)</option>
                  <option value="Feed Post / Carousel">Feed Post / Carousel</option>
                  <option value="Story Sequence (24h)">Story Sequence (24h)</option>
                  <option value="Full Content Bundle">Full Content Bundle</option>
                </select>
              </div>

              <div>
                <label class="block font-bold text-slate-700 mb-1" for="enq-budget">
                  Estimated Campaign Budget
                </label>
                <select id="enq-budget" name="budgetRange" class="w-full p-2.5 rounded-lg border border-slate-300 bg-white">
                  <option value="$500 – $1,000">$500 – $1,000</option>
                  <option value="$1,000 – $2,500" selected>$1,000 – $2,500</option>
                  <option value="$2,500 – $5,000">$2,500 – $5,000</option>
                  <option value="$5,000 – $10,000">$5,000 – $10,000</option>
                  <option value="$10,000+">$10,000+</option>
                </select>
              </div>

              <div>
                <label class="block font-bold text-slate-700 mb-1" for="enq-timeline">
                  Desired Posting Timeline
                </label>
                <input
                  type="text"
                  id="enq-timeline"
                  name="timeline"
                  placeholder="e.g. Next 3-4 weeks"
                  class="w-full p-2.5 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label class="block font-bold text-slate-700 mb-1" for="enq-usage">
                  Usage Rights Needed
                </label>
                <select id="enq-usage" name="usageRights" class="w-full p-2.5 rounded-lg border border-slate-300 bg-white">
                  <option value="Organic Posting Only">Organic Posting Only</option>
                  <option value="30-day Paid Ads Whitelisting">30-day Paid Ads Whitelisting</option>
                  <option value="90-day Multi-channel Digital Usage">90-day Multi-channel Digital Usage</option>
                  <option value="Perpetual Organic Reposting">Perpetual Organic Reposting</option>
                </select>
              </div>

              <!-- Brief / Notes -->
              <div class="sm:col-span-2">
                <label class="block font-bold text-slate-700 mb-1" for="enq-notes">
                  Campaign Brief & Special Instructions
                </label>
                <textarea
                  id="enq-notes"
                  name="campaignNotes"
                  rows="3"
                  placeholder="Outline key messaging, product shipping requirements, aesthetic expectations, or specific call-to-actions."
                  class="w-full p-2.5 rounded-lg border border-slate-300"
                ></textarea>
              </div>
            </div>

            <!-- Confirmation disclaimer -->
            <div class="p-3 bg-slate-50 rounded-lg border border-slate-200 text-[11px] text-slate-600">
              <strong>Next Steps:</strong> The CollabPromo team reviews all enquiries to verify commercial viability and creator availability before coordinating the introduction. You will receive an email confirmation.
            </div>

            <div class="pt-4 flex flex-col sm:flex-row items-center justify-end gap-3 border-t border-slate-100">
              <button type="button" data-action="close-modal" class="w-full sm:w-auto px-5 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900">
                Cancel
              </button>
              <button
                type="submit"
                class="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors"
              >
                Submit Campaign Proposal
              </button>
            </div>
          </form>
        </div>
      </div>
    `;

    // Handle Form submission
    const enquiryForm = document.getElementById('campaign-enquiry-form');
    if (enquiryForm) {
      enquiryForm.addEventListener('submit', (e) => {
        e.preventDefault();
        let isValid = true;

        const brandInput = document.getElementById('enq-brand-name');
        const errBrand = document.getElementById('err-enq-brand');
        if (!brandInput.value.trim()) {
          brandInput.classList.add('field-error-input');
          errBrand.classList.remove('hidden');
          isValid = false;
        } else {
          brandInput.classList.remove('field-error-input');
          errBrand.classList.add('hidden');
        }

        const contactInput = document.getElementById('enq-contact-person');
        const errContact = document.getElementById('err-enq-contact');
        if (!contactInput.value.trim()) {
          contactInput.classList.add('field-error-input');
          errContact.classList.remove('hidden');
          isValid = false;
        } else {
          contactInput.classList.remove('field-error-input');
          errContact.classList.add('hidden');
        }

        const emailInput = document.getElementById('enq-work-email');
        const errEmail = document.getElementById('err-enq-email');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailInput.value.trim() || !emailRegex.test(emailInput.value.trim())) {
          emailInput.classList.add('field-error-input');
          errEmail.classList.remove('hidden');
          isValid = false;
        } else {
          emailInput.classList.remove('field-error-input');
          errEmail.classList.add('hidden');
        }

        const campInput = document.getElementById('enq-campaign-name');
        const errCamp = document.getElementById('err-enq-campaign');
        if (!campInput.value.trim()) {
          campInput.classList.add('field-error-input');
          errCamp.classList.remove('hidden');
          isValid = false;
        } else {
          campInput.classList.remove('field-error-input');
          errCamp.classList.add('hidden');
        }

        if (!isValid) return;

        const targetSelect = document.getElementById('enq-creator-target');
        const targetCreatorId = targetSelect.value || null;
        const targetCreator = targetCreatorId ? store.getCreatorById(targetCreatorId) : null;

        const newEnquiry = store.addEnquiry({
          brandName: brandInput.value,
          contactPerson: contactInput.value,
          workEmail: emailInput.value,
          campaignName: campInput.value,
          campaignGoal: document.getElementById('enq-goal').value,
          desiredContentType: document.getElementById('enq-content-type').value,
          budgetRange: document.getElementById('enq-budget').value,
          timeline: document.getElementById('enq-timeline').value,
          usageRights: document.getElementById('enq-usage').value,
          campaignNotes: document.getElementById('enq-notes').value,
          selectedCreatorId: targetCreatorId,
          selectedCreatorName: targetCreator ? `${targetCreator.name} (${targetCreator.handle})` : null
        });

        // Show confirmation modal
        this.openEnquirySuccessModal(newEnquiry);
      });
    }

    this.activeModal = 'campaign-enquiry';
  }

  openEnquirySuccessModal(enquiry) {
    const modalContainer = document.getElementById('modal-container');
    if (!modalContainer) return;

    modalContainer.innerHTML = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 modal-backdrop">
        <div class="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative text-center">
          <div class="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4">
            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
          </div>

          <span class="text-xs font-mono font-bold text-blue-600">Enquiry Ref #${this.escapeHtml(enquiry.id)}</span>
          <h2 class="text-xl font-bold text-slate-900 mt-1">Campaign Enquiry Received!</h2>
          <p class="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
            Thank you, <strong>${this.escapeHtml(enquiry.contactPerson)}</strong>. We have received your campaign proposal for <strong>${this.escapeHtml(enquiry.campaignName)}</strong>.
          </p>

          <div class="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-left text-xs text-slate-700 space-y-1.5">
            <div><strong class="text-slate-900">What happens next:</strong></div>
            <p>1. CollabPromo reviews your parameters to confirm alignment with creator rates.</p>
            <p>2. We confirm the creator's current schedule availability.</p>
            <p>3. Our coordinator introduces both parties via email to finalize deliverables.</p>
            <p class="text-[11px] text-slate-400 italic pt-1">* An enquiry is an introductory request and not a confirmed booking.</p>
          </div>

          <div class="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button data-action="close-modal" class="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl transition-colors">
              Continue Browsing Creators
            </button>
            <a href="#brand-dashboard" data-action="close-modal" class="w-full sm:w-auto px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors">
              View in Brand Dashboard
            </a>
          </div>
        </div>
      </div>
    `;

    this.activeModal = 'enquiry-success';
  }

  openRoleSwitcherModal() {
    const currentUser = store.getCurrentUser();
    const modalContainer = document.getElementById('modal-container');
    if (!modalContainer) return;

    modalContainer.innerHTML = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 modal-backdrop">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
          <button data-action="close-modal" class="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-2 rounded-lg" aria-label="Close modal">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>

          <span class="text-xs font-bold uppercase tracking-wider text-blue-600">Testing & Prototype Switcher</span>
          <h2 class="text-lg font-bold text-slate-900 mt-1">Switch Account Experience</h2>
          <p class="text-xs text-slate-500 mt-1 mb-4">
            Test the website as different personas to inspect dedicated views and permissions:
          </p>

          <div class="space-y-2.5 text-left">
            <!-- Brand Option -->
            <button
              data-switch-role="brand"
              class="w-full p-3.5 rounded-xl border ${
                currentUser.role === 'brand' ? 'border-blue-500 bg-blue-50/50' : 'border-slate-200 hover:bg-slate-50'
              } flex items-center gap-3 transition-colors text-left"
            >
              <div class="w-9 h-9 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-sm">B</div>
              <div class="flex-1">
                <div class="font-bold text-xs text-slate-900">Brand Persona (Lumina Skin Co.)</div>
                <div class="text-[11px] text-slate-500">Access directory, filters, rate cards, and submit campaign briefs</div>
              </div>
              ${currentUser.role === 'brand' ? '<span class="text-xs font-bold text-blue-600">Active</span>' : ''}
            </button>

            <!-- Creator Option -->
            <button
              data-switch-role="creator"
              class="w-full p-3.5 rounded-xl border ${
                currentUser.role === 'creator' ? 'border-purple-500 bg-purple-50/50' : 'border-slate-200 hover:bg-slate-50'
              } flex items-center gap-3 transition-colors text-left"
            >
              <div class="w-9 h-9 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-sm">C</div>
              <div class="flex-1">
                <div class="font-bold text-xs text-slate-900">Creator Persona (Maya Lin)</div>
                <div class="text-[11px] text-slate-500">Access creator dashboard, edit rate card, check incoming enquiries</div>
              </div>
              ${currentUser.role === 'creator' ? '<span class="text-xs font-bold text-purple-600">Active</span>' : ''}
            </button>

            <!-- Admin Option -->
            <button
              data-switch-role="admin"
              class="w-full p-3.5 rounded-xl border ${
                currentUser.role === 'admin' ? 'border-amber-500 bg-amber-50/50' : 'border-slate-200 hover:bg-slate-50'
              } flex items-center gap-3 transition-colors text-left"
            >
              <div class="w-9 h-9 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-sm">A</div>
              <div class="flex-1">
                <div class="font-bold text-xs text-slate-900">Platform Administrator</div>
                <div class="text-[11px] text-slate-500">Approve/hide directory listings, review consent, manage enquiries</div>
              </div>
              ${currentUser.role === 'admin' ? '<span class="text-xs font-bold text-amber-600">Active</span>' : ''}
            </button>

            <!-- Guest Option -->
            <button
              data-switch-role="guest"
              class="w-full p-3.5 rounded-xl border ${
                currentUser.role === 'guest' ? 'border-slate-400 bg-slate-100' : 'border-slate-200 hover:bg-slate-50'
              } flex items-center gap-3 transition-colors text-left"
            >
              <div class="w-9 h-9 rounded-lg bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-sm">V</div>
              <div class="flex-1">
                <div class="font-bold text-xs text-slate-900">Public Visitor (Guest)</div>
                <div class="text-[11px] text-slate-500">Standard homepage, browse public creators, register as new role</div>
              </div>
              ${currentUser.role === 'guest' ? '<span class="text-xs font-bold text-slate-600">Active</span>' : ''}
            </button>
          </div>
        </div>
      </div>
    `;

    this.activeModal = 'role-switcher';
  }

  closeModal() {
    const modalContainer = document.getElementById('modal-container');
    if (modalContainer) {
      modalContainer.innerHTML = '';
    }
    this.activeModal = null;
    this.selectedCreatorForModal = null;
  }

  // ==========================================
  // HELPERS & FILTER LOGIC
  // ==========================================

  applyFilters(creators) {
    return creators
      .filter(c => {
        // Search filter (name, handle, bio, niche)
        if (this.filters.search.trim()) {
          const q = this.filters.search.toLowerCase().trim();
          const matches =
            c.name.toLowerCase().includes(q) ||
            c.handle.toLowerCase().includes(q) ||
            c.niche.toLowerCase().includes(q) ||
            (c.bio && c.bio.toLowerCase().includes(q)) ||
            c.location.toLowerCase().includes(q);
          if (!matches) return false;
        }

        // Platform filter
        if (this.filters.platform && this.filters.platform !== 'all') {
          if (c.platform !== this.filters.platform) return false;
        }

        // Niche filter
        if (this.filters.niche && this.filters.niche !== 'All Categories') {
          if (c.niche !== this.filters.niche) return false;
        }

        // Followers filter
        if (this.filters.minFollowers !== null && c.followers < this.filters.minFollowers) {
          return false;
        }
        if (this.filters.maxFollowers !== null && c.followers > this.filters.maxFollowers) {
          return false;
        }

        // Reel Rate filter
        if (this.filters.maxRateReel !== null && c.rateReel > this.filters.maxRateReel) {
          return false;
        }

        // Open to collabs only
        if (this.filters.openToCollabsOnly && !c.isOpenToCollabs) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (this.filters.sortBy === 'followers_desc') {
          return b.followers - a.followers;
        }
        if (this.filters.sortBy === 'followers_asc') {
          return a.followers - b.followers;
        }
        if (this.filters.sortBy === 'reel_asc') {
          return a.rateReel - b.rateReel;
        }
        if (this.filters.sortBy === 'reel_desc') {
          return b.rateReel - a.rateReel;
        }
        if (this.filters.sortBy === 'post_asc') {
          return a.ratePost - b.ratePost;
        }
        return 0;
      });
  }

  formatNumber(num) {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    }
    return num ? num.toLocaleString() : '0';
  }

  escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl shadow-lg text-xs font-semibold text-white transition-all transform duration-300 flex items-center gap-2 ${
      type === 'error' ? 'bg-red-600' : 'bg-slate-900'
    }`;
    toast.innerHTML = `
      <svg class="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
      <span>${this.escapeHtml(message)}</span>
    `;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }
}

// Reliable Initialization (handles both early and late script execution)
function initCollabPromoApp() {
  if (!window.collabApp) {
    window.collabApp = new CollabPromoApp();
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initCollabPromoApp);
} else {
  initCollabPromoApp();
}
